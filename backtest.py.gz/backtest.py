"""2-year backtest of the USD/JPY paper bot and a few variants (research only)."""
import json, os, datetime as dt
import numpy as np, pandas as pd, yfinance as yf

RISK = 10.0
DAY_LIMIT = 30.0
JST = dt.timezone(dt.timedelta(hours=9))


def indicators(df):
    c = df["Close"]
    df["ema20"] = c.ewm(span=20, adjust=False).mean()
    df["ema50"] = c.ewm(span=50, adjust=False).mean()
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    df["rsi"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - c.shift()).abs(), (df["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    df["atr"] = tr.rolling(14).mean()
    df["ema200"] = c.ewm(span=200, adjust=False).mean()
    return df


def run(df, spread=0.0, weekend=False, breakeven=False, trail=False, sessions=False, tp_mult=2.0, trend200=False):
    bal, pos, day, dpnl, halted = 1000.0, None, None, 0.0, False
    trades, curve = [], []
    for ts, r in df.iterrows():
        utc = ts.tz_convert("UTC")
        d = ts.tz_convert(JST).strftime("%Y-%m-%d")
        if d != day:
            day, dpnl, halted = d, 0.0, False
        fri_late = utc.weekday() == 4 and utc.hour >= 19
        if pos:
            side = 1 if pos["side"] == "buy" else -1
            exitp, why = None, None
            if side == 1 and r["Low"] <= pos["stop"]:
                exitp, why = pos["stop"], "stop"
            elif side == -1 and r["High"] >= pos["stop"]:
                exitp, why = pos["stop"], "stop"
            elif side == 1 and r["High"] >= pos["tp"]:
                exitp, why = pos["tp"], "target"
            elif side == -1 and r["Low"] <= pos["tp"]:
                exitp, why = pos["tp"], "target"
            elif weekend and fri_late:
                exitp, why = float(r["Close"]), "weekend"
            if exitp is not None:
                exitp -= side * spread / 2
                pnl = (exitp - pos["entry"]) * pos["units"] * side / exitp
                bal += pnl
                dpnl += pnl
                trades.append({"pnl": pnl, "why": why, "t": ts})
                pos = None
                if dpnl <= -DAY_LIMIT:
                    halted = True
            else:
                R = pos["dist"]
                prog = (float(r["Close"]) - pos["entry"]) * side
                if breakeven and prog >= R and (pos["stop"] - pos["entry"]) * side < 0:
                    pos["stop"] = pos["entry"]
                if trail and not np.isnan(r["atr"]):
                    ns = float(r["Close"]) - side * 1.5 * r["atr"]
                    if (ns - pos["stop"]) * side > 0:
                        pos["stop"] = ns
        if pos is None and not halted and not np.isnan(r["atr"]):
            if weekend and (fri_late or (utc.weekday() == 4 and utc.hour >= 15)):
                pass
            elif sessions and not (7 <= utc.hour <= 20):
                pass
            else:
                side = None
                if r["ema20"] > r["ema50"] and 50 < r["rsi"] < 70 and r["Close"] > r["ema20"] and (not trend200 or r["Close"] > r["ema200"]):
                    side = "buy"
                elif r["ema20"] < r["ema50"] and 30 < r["rsi"] < 50 and r["Close"] < r["ema20"] and (not trend200 or r["Close"] < r["ema200"]):
                    side = "sell"
                if side:
                    s = 1 if side == "buy" else -1
                    dist = 1.5 * r["atr"]
                    price = float(r["Close"]) + s * spread / 2
                    pos = {"side": side, "entry": price, "dist": dist, "units": RISK * price / dist,
                           "stop": price - s * dist, "tp": price + s * tp_mult * dist}
        curve.append(bal)
    curve = np.array(curve)
    peak = np.maximum.accumulate(curve)
    dd = float((peak - curve).max())
    wins = [t["pnl"] for t in trades if t["pnl"] > 0]
    losses = [-t["pnl"] for t in trades if t["pnl"] <= 0]
    half = df.index[len(df) // 2]
    p1 = sum(t["pnl"] for t in trades if t["t"] < half)
    p2 = sum(t["pnl"] for t in trades if t["t"] >= half)
    months = {}
    for t in trades:
        k = t["t"].strftime("%Y-%m")
        months[k] = months.get(k, 0) + t["pnl"]
    return {"trades": len(trades), "pnl": round(bal - 1000, 2), "win_rate": round(100 * len(wins) / max(len(trades), 1), 1),
            "profit_factor": round(sum(wins) / max(sum(losses), 1e-9), 2), "max_drawdown": round(dd, 2),
            "pnl_first_half": round(p1, 2), "pnl_second_half": round(p2, 2),
            "losing_months": sum(1 for v in months.values() if v < 0), "months": len(months),
            "worst_month": round(min(months.values()), 2) if months else 0}


def main():
    df = yf.download("USDJPY=X", period="730d", interval="1h", progress=False, auto_adjust=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = indicators(df.dropna(subset=["Close"])).iloc[200:]
    sp = 0.003  # ~0.3 pip spread + slippage
    variants = {
        "A_current": dict(),
        "B_realistic(spread+weekend)": dict(spread=sp, weekend=True),
        "C_B+breakeven": dict(spread=sp, weekend=True, breakeven=True),
        "D_B+trailing": dict(spread=sp, weekend=True, trail=True),
        "E_B+sessions": dict(spread=sp, weekend=True, sessions=True),
        "F_B+ema200": dict(spread=sp, weekend=True, trend200=True),
        "G_B+tp1.5R": dict(spread=sp, weekend=True, tp_mult=1.5),
        "H_B+tp3R": dict(spread=sp, weekend=True, tp_mult=3.0),
    }
    out = {"period": f"{df.index[0]} -> {df.index[-1]}", "bars": len(df), "results": {}}
    for k, v in variants.items():
        out["results"][k] = run(df, **v)
        print(k, out["results"][k])
    os.makedirs("fx", exist_ok=True)
    json.dump(out, open("fx/backtest.json", "w"), indent=1)


if __name__ == "__main__":
    main()
