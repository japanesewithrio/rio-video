"""USD/JPY daily report + paper-trading bot (no real money).
Strategy: 1h EMA20/EMA50 trend + RSI filter, ATR stop, fixed $10 risk per trade,
daily loss limit $30 (JST day). State is kept in fx/state.json."""
import json, os, urllib.request, urllib.parse, datetime as dt
import numpy as np, pandas as pd, yfinance as yf

RISK_PER_TRADE = 10.0     # USD lost if stop is hit
DAILY_LOSS_LIMIT = 30.0   # USD, bot stops for the rest of the JST day
START_BALANCE = 1000.0
SPREAD = 0.003           # yen, ~0.3 pip spread + slippage
JST = dt.timezone(dt.timedelta(hours=9))
ST = "fx/state.json"
EVENTS = []


def jst(t):
    """candle start (iso) -> JST time of the candle close"""
    x = dt.datetime.fromisoformat(t) + dt.timedelta(hours=1)
    return x.astimezone(JST).strftime("%m/%d %H:%M")


def alert_text(kind, x, bal):
    warn = "\n\n\u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b"
    if kind == "open":
        side = "\U0001f7e2 BUY (\u101d\u101a\u103a)" if x["side"] == "buy" else "\U0001f534 SELL (\u101b\u1031\u102c\u1004\u103a\u1038)"
        return ("\U0001f514 \u1004\u103d\u1031\u1010\u102f bot trade \u101d\u1004\u103a\u1015\u103c\u102e!\n\n"
                f"{side} USD/JPY\n\U0001f4cd \u101d\u1004\u103a\u1008\u1031\u1038: {x['entry']}\n"
                f"\U0001f6d1 Stop: {x['stop']} (\u1011\u102d\u101b\u1004\u103a -$10)\n"
                f"\U0001f3af Target: {x['tp']} (\u1011\u102d\u101b\u1004\u103a +$20)\n"
                f"\U0001f550 {jst(x['ts'])} (JST)" + warn)
    if kind == "close":
        if x.get("why") == "weekend":
            head = "\U0001f4c5 \u1005\u1014\u1031 \u1008\u1031\u1038\u1015\u102d\u1010\u103a\u1001\u102b\u1014\u102e\u1038\u101c\u102d\u102f\u1037 \u1015\u102d\u1010\u103a\u101c\u102d\u102f\u1000\u103a\u1010\u101a\u103a"
            return (f"{head} {'+' if x['pnl'] > 0 else '-'}${abs(x['pnl']):.2f}\n\n"
                    f"{x['side'].upper()} {x['entry']} \u2192 {x['exit']}\n"
                    f"\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}" + warn)
        head = ("\u2705 Target \u1011\u102d\u1015\u103c\u102e! \u1019\u103c\u1010\u103a\u1010\u101a\u103a" if x["pnl"] > 0
                else "\u274c Stop \u1011\u102d\u1015\u103c\u102e\u104b \u101b\u103e\u102f\u1036\u1038\u1010\u101a\u103a")
        return (f"{head} {'+' if x['pnl'] > 0 else '-'}${abs(x['pnl']):.2f}\n\n"
                f"{x['side'].upper()} {x['entry']} \u2192 {x['exit']}\n"
                f"\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f} (\u1021\u1005 $1,000)\n"
                f"\U0001f550 {jst(x['close'])} (JST)" + warn)
    if kind == "test":
        return ("\u2705 \u1001\u103b\u102d\u1010\u103a\u1006\u1000\u103a\u1019\u103e\u102f \u1021\u1031\u102c\u1004\u103a\u1019\u103c\u1004\u103a\u1015\u102b\u1015\u103c\u102e! (test)\n\n"
                "\u1004\u103d\u1031\u1010\u102f bot \u1000 trade \u101d\u1004\u103a/\u1011\u103d\u1000\u103a\u1010\u102c\u1014\u1032\u1037 \u1012\u102e\u1019\u103e\u102c \u1001\u103b\u1000\u103a\u1001\u103b\u1004\u103a\u1038 \u1015\u102d\u102f\u1037\u1015\u1031\u1038\u1019\u101a\u103a\u104b\n\n"
                f"\U0001f4c8 USD/JPY: {x['price']}\n\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}\n"
                f"\U0001f4c2 Position: {x['pos']}\n\U0001f550 {x['t']} (JST)" + warn)
    return ("\u26d4 \u1012\u102e\u1014\u1031\u1037 -$30 \u1015\u103c\u100a\u103a\u1037\u101c\u102d\u102f\u1037 bot \u101b\u1015\u103a\u101c\u102d\u102f\u1000\u103a\u1015\u103c\u102e\u104b "
            "\u100a\u101e\u1014\u103a\u1038\u1001\u1031\u102b\u1004\u103a 0:00 (JST) \u1019\u103e\u102c \u1015\u103c\u1014\u103a\u1005\u1019\u101a\u103a\u104b"
            f"\n\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}" + warn)


def send_alerts(rep=None):
    tok, chat = os.environ.get("TG_TOKEN"), os.environ.get("TG_CHAT")
    try:
        is_test = os.environ.get("GITHUB_EVENT_NAME") == "push" and open("fx/trigger.txt").read().startswith("TEST")
    except Exception:
        is_test = False
    if is_test and rep:
        pp = rep["paper"]
        pos = pp["open_position"]
        EVENTS.insert(0, ("test", {"price": rep["price"], "t": rep["time_jst"],
                                   "pos": (pos["side"].upper() + " @ " + str(pos["entry"])) if pos else "-"}, pp["balance"]))
    if not (tok and chat):
        print("no telegram secrets;", len(EVENTS), "events")
        return
    for kind, x, bal in EVENTS:
        try:
            text = x if kind == "raw" else alert_text(kind, x, bal)
            data = urllib.parse.urlencode({"chat_id": chat, "text": text}).encode()
            urllib.request.urlopen("https://api.telegram.org/bot" + tok + "/sendMessage", data, timeout=20)
        except Exception as e:
            print("telegram error", type(e).__name__)


def load_state():
    if os.path.exists(ST):
        return json.load(open(ST))
    return {"balance": START_BALANCE, "position": None, "last_ts": None,
            "day": None, "day_pnl": 0.0, "halted": False, "trades": []}


def indicators(df):
    c = df["Close"]
    df["ema20"] = c.ewm(span=20, adjust=False).mean()
    df["ema50"] = c.ewm(span=50, adjust=False).mean()
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    df["rsi"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - c.shift()).abs(), (df["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    df["atr"] = tr.rolling(14).mean()
    return df


def step(s, ts, t, r):
        day = ts.tz_convert(JST).strftime("%Y-%m-%d") if ts.tzinfo else ts.strftime("%Y-%m-%d")
        if day != s["day"]:
            s["day"], s["day_pnl"], s["halted"] = day, 0.0, False
        pos = s["position"]
        utc = ts.tz_convert("UTC")
        fri_late = utc.weekday() == 4 and utc.hour >= 19
        if pos:
            sgn = 1 if pos["side"] == "buy" else -1
            if pos["side"] == "buy" and r["Low"] <= pos["stop"]:
                close_pos(s, pos, pos["stop"] - sgn * SPREAD / 2, t, "stop")
            elif pos["side"] == "sell" and r["High"] >= pos["stop"]:
                close_pos(s, pos, pos["stop"] - sgn * SPREAD / 2, t, "stop")
            elif pos["side"] == "buy" and r["High"] >= pos["tp"]:
                close_pos(s, pos, pos["tp"] - sgn * SPREAD / 2, t, "target")
            elif pos["side"] == "sell" and r["Low"] <= pos["tp"]:
                close_pos(s, pos, pos["tp"] - sgn * SPREAD / 2, t, "target")
            elif fri_late:
                close_pos(s, pos, float(r["Close"]) - sgn * SPREAD / 2, t, "weekend")
        no_entry = (utc.weekday() == 4 and utc.hour >= 15) or not (7 <= utc.hour <= 20)
        if not s["position"] and not s["halted"] and not no_entry and not np.isnan(r["atr"]):
            side = None
            if r["ema20"] > r["ema50"] and 50 < r["rsi"] < 70 and r["Close"] > r["ema20"]:
                side = "buy"
            elif r["ema20"] < r["ema50"] and 30 < r["rsi"] < 50 and r["Close"] < r["ema20"]:
                side = "sell"
            if side:
                dist = 1.5 * r["atr"]
                price = float(r["Close"]) + (SPREAD / 2 if side == "buy" else -SPREAD / 2)
                units = RISK_PER_TRADE * price / dist
                s["position"] = {"side": side, "entry": round(price, 3), "units": round(units),
                                 "stop": round(price - dist if side == "buy" else price + dist, 3),
                                 "tp": round(price + 2 * dist if side == "buy" else price - 2 * dist, 3), "ts": t}
                EVENTS.append(("open", s["position"], s["balance"]))
        s["last_ts"] = t


def close_pos(s, pos, price, ts, why):
    pnl_jpy = (price - pos["entry"]) * pos["units"] * (1 if pos["side"] == "buy" else -1)
    pnl = pnl_jpy / price
    s["balance"] = round(s["balance"] + pnl, 2)
    s["day_pnl"] = round(s["day_pnl"] + pnl, 2)
    s["trades"].append({"side": pos["side"], "entry": pos["entry"], "exit": round(price, 3),
                        "open": pos["ts"], "close": ts, "pnl": round(pnl, 2), "why": why})
    s["position"] = None
    EVENTS.append(("close", s["trades"][-1], s["balance"]))
    if s["day_pnl"] <= -DAILY_LOSS_LIMIT:
        s["halted"] = True
        EVENTS.append(("halt", None, s["balance"]))


def simulate(df, s):
    for ts, r in df.iloc[60:].iterrows():
        t = ts.isoformat()
        if s["last_ts"] and t <= s["last_ts"]:
            continue
        step(s, ts, t, r)
    return s


# ---------------- daily bots (chosen by train/test research, see fx/research.json) ----------------
SWAP_DIFF = 3.3  # % per year, rough USD-JPY rate gap: long USD earns, short pays
DAILY_BOTS = {
    "B": {"label": "Bot B \u2013 \u1014\u1031\u1037\u1005\u1009\u103a Breakout (20)", "kind": "breakout", "n": 20, "stop_atr": 3.0},
    "C": {"label": "Bot C \u2013 \u1014\u1031\u1037\u1005\u1009\u103a Trend (EMA20/100)", "kind": "ema", "fast": 20, "slow": 100, "stop_atr": 3.0},
}


def daily_signal(cfg, d, i):
    C = d["Close"].values
    if cfg["kind"] == "breakout":
        hi = d["High"].rolling(cfg["n"]).max().shift(1).values
        lo = d["Low"].rolling(cfg["n"]).min().shift(1).values
        if np.isnan(hi[i]):
            return 0
        return 1 if C[i] > hi[i] else (-1 if C[i] < lo[i] else 0)
    f = d["Close"].ewm(span=cfg["fast"], adjust=False).mean().values
    sl = d["Close"].ewm(span=cfg["slow"], adjust=False).mean().values
    if i < cfg["slow"]:
        return 0
    return 1 if f[i] > sl[i] else -1


def daily_text(cfg, kind, pos, bal, extra=None):
    warn = "\n\n\u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b"
    head = "\U0001f916 " + cfg["label"] + "\n"
    side = "\U0001f7e2 BUY (\u101d\u101a\u103a)" if pos["s"] == 1 else "\U0001f534 SELL (\u101b\u1031\u102c\u1004\u103a\u1038)"
    if kind == "open":
        return (head + "\U0001f514 trade \u101d\u1004\u103a\u1015\u103c\u102e!\n\n" + f"{side} USD/JPY\n\U0001f4cd \u101d\u1004\u103a\u1008\u1031\u1038: {pos['e']:.3f}\n"
                f"\U0001f6d1 Stop: {pos['stop']:.3f} (\u1011\u102d\u101b\u1004\u103a -$10)\n"
                "\U0001f3af Target \u1019\u101b\u103e\u102d\u1018\u1030\u1038 \u2013 trend \u1015\u103c\u1031\u102c\u1004\u103a\u1038\u1019\u103e \u1011\u103d\u1000\u103a\u1019\u101a\u103a" + warn)
    pnl, exitp, why = extra
    mark = "\u2705" if pnl > 0 else "\u274c"
    whys = {"stop": "Stop \u1011\u102d\u101c\u102d\u102f\u1037", "signal": "Trend \u1015\u103c\u1031\u102c\u1004\u103a\u1038\u101c\u102d\u102f\u1037"}
    return (head + f"{mark} trade \u1015\u102d\u1010\u103a\u1015\u103c\u102e ({whys.get(why, why)}) {'+' if pnl > 0 else '-'}${abs(pnl):.2f}\n\n"
            f"{'BUY' if pos['s'] == 1 else 'SELL'} {pos['e']:.3f} \u2192 {exitp:.3f}\n\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f} (\u1021\u1005 $1,000)" + warn)


def run_daily(s):
    d = yf.download("USDJPY=X", period="2y", interval="1d", progress=False, auto_adjust=False)
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = d.columns.get_level_values(0)
    d = d.dropna(subset=["Close"])
    d = d[(d["High"] >= d["Low"]) & (d["Close"] > 50)]
    c = d["Close"]
    tr = pd.concat([d["High"] - d["Low"], (d["High"] - c.shift()).abs(), (d["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    d["atr"] = tr.rolling(14).mean()
    d = d.iloc[:-1]  # today's daily candle is not finished
    H, L, C, A = d["High"].values, d["Low"].values, d["Close"].values, d["atr"].values
    keys = [x.strftime("%Y-%m-%d") for x in d.index]
    bots = s.setdefault("daily", {})
    for name, cfg in DAILY_BOTS.items():
        b = bots.setdefault(name, {"balance": START_BALANCE, "position": None, "last": keys[-1], "trades": []})
        for i in range(len(d)):
            if keys[i] <= b["last"]:
                continue
            pos = b["position"]
            if pos:
                sg = pos["s"]
                b["balance"] += sg * pos["units"] * SWAP_DIFF / 100 / 365
                hit, why = None, None
                if (sg == 1 and L[i] <= pos["stop"]) or (sg == -1 and H[i] >= pos["stop"]):
                    hit, why = pos["stop"], "stop"
                elif daily_signal(cfg, d, i) == -sg:
                    hit, why = float(C[i]), "signal"
                if hit is not None:
                    ex = hit - sg * SPREAD / 2
                    pnl = (ex - pos["e"]) * pos["units"] * sg / ex
                    b["balance"] = round(b["balance"] + pnl, 2)
                    b["trades"].append({"side": "buy" if sg == 1 else "sell", "entry": round(pos["e"], 3), "exit": round(ex, 3),
                                        "open": pos["date"], "close": keys[i], "pnl": round(pnl, 2), "why": why})
                    EVENTS.append(("raw", daily_text(cfg, "close", pos, b["balance"], (pnl, ex, why)), b["balance"]))
                    b["position"] = None
            if b["position"] is None and not np.isnan(A[i]) and A[i] > 0:
                sig = daily_signal(cfg, d, i)
                if sig:
                    e = float(C[i]) + sig * SPREAD / 2
                    dist = cfg["stop_atr"] * A[i]
                    b["position"] = {"s": sig, "e": e, "units": RISK_PER_TRADE * e / dist, "stop": e - sig * dist, "date": keys[i]}
                    EVENTS.append(("raw", daily_text(cfg, "open", b["position"], b["balance"]), b["balance"]))
            b["last"] = keys[i]
        b["balance"] = round(b["balance"], 2)
        b["trades"] = b["trades"][-100:]
    return {n: {"label": DAILY_BOTS[n]["label"], "balance": b["balance"], "open_position":
                ({"side": "buy" if b["position"]["s"] == 1 else "sell", "entry": round(b["position"]["e"], 3),
                  "stop": round(b["position"]["stop"], 3), "since": b["position"]["date"]} if b["position"] else None),
                "total_trades": len(b["trades"]), "last_trades": b["trades"][-3:]} for n, b in bots.items()}


def run():
    df = yf.download("USDJPY=X", period="30d", interval="1h", progress=False, auto_adjust=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = indicators(df.dropna(subset=["Close"]))
    fresh = not os.path.exists(ST)
    bt = simulate(df, {"balance": START_BALANCE, "position": None, "last_ts": None,
                       "day": None, "day_pnl": 0.0, "halted": False, "trades": []})
    s = load_state()
    done = df.iloc[:-1]  # last hourly candle is still forming
    if fresh:
        s["last_ts"] = done.index[-1].isoformat()
    EVENTS.clear()
    simulate(done, s)
    s["trades"] = s["trades"][-200:]
    try:
        daily_bots = run_daily(s)
    except Exception as e:
        print("daily bots error", type(e).__name__, e)
        daily_bots = None
    last = df.iloc[-1]
    d24 = df[df.index >= df.index[-1] - pd.Timedelta(hours=24)]
    closed = [x for x in s["trades"] if x["close"] >= (df.index[-1] - pd.Timedelta(hours=24)).isoformat()]
    rep = {
        "time_jst": dt.datetime.now(JST).strftime("%Y-%m-%d %H:%M"),
        "price": round(float(last["Close"]), 3),
        "change_24h": round(float(last["Close"] - d24["Close"].iloc[0]), 3),
        "high_24h": round(float(d24["High"].max()), 3), "low_24h": round(float(d24["Low"].min()), 3),
        "week_change": round(float(last["Close"] - df["Close"].iloc[-120]), 3) if len(df) > 120 else None,
        "trend": "up" if last["ema20"] > last["ema50"] else "down",
        "rsi": round(float(last["rsi"]), 1), "atr": round(float(last["atr"]), 3),
        "paper": {"balance": s["balance"], "start": START_BALANCE, "day_pnl": s["day_pnl"],
                  "halted_today": s["halted"], "open_position": s["position"],
                  "trades_24h": closed, "total_trades": len(s["trades"]),
                  "win_rate": round(100 * sum(1 for x in s["trades"] if x["pnl"] > 0) / len(s["trades"]), 1) if s["trades"] else None,
                  "backtest_30d": {"trades": len(bt["trades"]), "pnl": round(bt["balance"] - START_BALANCE, 2),
                                   "win_rate": round(100 * sum(1 for x in bt["trades"] if x["pnl"] > 0) / len(bt["trades"]), 1) if bt["trades"] else None},
                  "rules": "EMA20/EMA50 trend + RSI, stop 1.5xATR, target 3xATR, $10 risk/trade, stop for the day at -$30, spread 0.3 pip counted, entries only 16:00-05:59 JST (London/NY), closes before the weekend", "backtest_2y": "about break-even over ~2.7 years (profit factor ~1.0, max drawdown ~$330-530): no proven edge"},
        "daily_bots": daily_bots,
        "daily_bots_note": "Bot B (daily 20-day breakout, 3xATR stop) and Bot C (daily EMA20/100 trend, 3xATR stop) each start with $1000 fake money, $10 risk/trade, swap counted. Research: profitable on 2010-2019 (train) AND 2020-2026 (unseen test), but only ~3 trades per year and helped by the strong 2021-2024 USD/JPY uptrend.",
    }
    json.dump(s, open(ST, "w"), indent=1)
    json.dump(rep, open("fx/report.json", "w"), ensure_ascii=False, indent=1)
    print(json.dumps(rep, indent=1))
    send_alerts(rep)


if __name__ == "__main__":
    os.makedirs("fx", exist_ok=True)
    run()
