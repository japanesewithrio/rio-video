"""USD/JPY daily report + paper-trading bot (no real money).
Strategy: 1h EMA20/EMA50 trend + RSI filter, ATR stop, fixed $10 risk per trade,
daily loss limit $30 (JST day). State is kept in fx/state.json."""
import json, os, urllib.request, urllib.parse, datetime as dt
import numpy as np, pandas as pd, yfinance as yf

RISK_PER_TRADE = 10.0     # USD lost if stop is hit
DAILY_LOSS_LIMIT = 30.0   # USD, bot stops for the rest of the JST day
START_BALANCE = 1000.0
SPREAD = 0.003           # yen, ~0.3 pip spread + slippage
JST = dt.timezone(dt.timedelta(hours=9))
ST = "fx/state.json"
EVENTS = []


def jst(t):
    """candle start (iso) -> JST time of the candle close"""
    x = dt.datetime.fromisoformat(t) + dt.timedelta(hours=1)
    return x.astimezone(JST).strftime("%m/%d %H:%M")


def alert_text(kind, x, bal):
    warn = "\n\n\u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b"
    if kind == "open":
        side = "\U0001f7e2 BUY (\u101d\u101a\u103a)" if x["side"] == "buy" else "\U0001f534 SELL (\u101b\u1031\u102c\u1004\u103a\u1038)"
        return ("\U0001f514 \u1004\u103d\u1031\u1010\u102f bot trade \u101d\u1004\u103a\u1015\u103c\u102e!\n\n"
                f"{side} USD/JPY\n\U0001f4cd \u101d\u1004\u103a\u1008\u1031\u1038: {x['entry']}\n"
                f"\U0001f6d1 Stop: {x['stop']} (\u1011\u102d\u101b\u1004\u103a -$10)\n"
                f"\U0001f3af Target: {x['tp']} (\u1011\u102d\u101b\u1004\u103a +$20)\n"
                f"\U0001f550 {jst(x['ts'])} (JST)" + warn)
    if kind == "close":
        if x.get("why") == "weekend":
            head = "\U0001f4c5 \u1005\u1014\u1031 \u1008\u1031\u1038\u1015\u102d\u1010\u103a\u1001\u102b\u1014\u102e\u1038\u101c\u102d\u102f\u1037 \u1015\u102d\u1010\u103a\u101c\u102d\u102f\u1000\u103a\u1010\u101a\u103a"
            return (f"{head} {'+' if x['pnl'] > 0 else '-'}${abs(x['pnl']):.2f}\n\n"
                    f"{x['side'].upper()} {x['entry']} \u2192 {x['exit']}\n"
                    f"\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}" + warn)
        head = ("\u2705 Target \u1011\u102d\u1015\u103c\u102e! \u1019\u103c\u1010\u103a\u1010\u101a\u103a" if x["pnl"] > 0
                else "\u274c Stop \u1011\u102d\u1015\u103c\u102e\u104b \u101b\u103e\u102f\u1036\u1038\u1010\u101a\u103a")
        return (f"{head} {'+' if x['pnl'] > 0 else '-'}${abs(x['pnl']):.2f}\n\n"
                f"{x['side'].upper()} {x['entry']} \u2192 {x['exit']}\n"
                f"\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f} (\u1021\u1005 $1,000)\n"
                f"\U0001f550 {jst(x['close'])} (JST)" + warn)
    if kind == "test":
        return ("\u2705 \u1001\u103b\u102d\u1010\u103a\u1006\u1000\u103a\u1019\u103e\u102f \u1021\u1031\u102c\u1004\u103a\u1019\u103c\u1004\u103a\u1015\u102b\u1015\u103c\u102e! (test)\n\n"
                "\u1004\u103d\u1031\u1010\u102f bot \u1000 trade \u101d\u1004\u103a/\u1011\u103d\u1000\u103a\u1010\u102c\u1014\u1032\u1037 \u1012\u102e\u1019\u103e\u102c \u1001\u103b\u1000\u103a\u1001\u103b\u1004\u103a\u1038 \u1015\u102d\u102f\u1037\u1015\u1031\u1038\u1019\u101a\u103a\u104b\n\n"
                f"\U0001f4c8 USD/JPY: {x['price']}\n\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}\n"
                f"\U0001f4c2 Position: {x['pos']}\n\U0001f550 {x['t']} (JST)" + warn)
    return ("\u26d4 \u1012\u102e\u1014\u1031\u1037 -$30 \u1015\u103c\u100a\u103a\u1037\u101c\u102d\u102f\u1037 bot \u101b\u1015\u103a\u101c\u102d\u102f\u1000\u103a\u1015\u103c\u102e\u104b "
            "\u100a\u101e\u1014\u103a\u1038\u1001\u1031\u102b\u1004\u103a 0:00 (JST) \u1019\u103e\u102c \u1015\u103c\u1014\u103a\u1005\u1019\u101a\u103a\u104b"
            f"\n\U0001f4b0 \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${bal:,.2f}" + warn)


def send_alerts(rep=None):
    tok, chat = os.environ.get("TG_TOKEN"), os.environ.get("TG_CHAT")
    try:
        is_test = os.environ.get("GITHUB_EVENT_NAME") == "push" and open("fx/trigger.txt").read().startswith("TEST")
    except Exception:
        is_test = False
    if is_test and rep:
        pp = rep["paper"]
        pos = pp["open_position"]
        EVENTS.insert(0, ("test", {"price": rep["price"], "t": rep["time_jst"],
                                   "pos": (pos["side"].upper() + " @ " + str(pos["entry"])) if pos else "-"}, pp["balance"]))
    if not (tok and chat):
        print("no telegram secrets;", len(EVENTS), "events")
        return
    for kind, x, bal in EVENTS:
        try:
            text = x if kind == "raw" else alert_text(kind, x, bal)
            data = urllib.parse.urlencode({"chat_id": chat, "text": text}).encode()
            urllib.request.urlopen("https://api.telegram.org/bot" + tok + "/sendMessage", data, timeout=20)
        except Exception as e:
            print("telegram error", type(e).__name__)


# ---------------- evening Burmese report (Gemini writes it, sent straight to Telegram) ----------------
REPORT_HOUR_JST = 20  # first hourly run at/after 20:00 JST sends the day's report (Mon-Fri)
GEMINI_MODELS = ["gemini-3.6-flash", "gemini-3.8-flash", "gemini-3.5-flash", "gemini-flash-latest", "gemini-2.5-flash"]


def gemini_text(prompt):
    key = os.environ.get("GEMINI_API_KEY")
    if not key:
        return None
    body = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode()
    for m in GEMINI_MODELS:
        try:
            req = urllib.request.Request("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent",
                                         body, {"Content-Type": "application/json", "x-goog-api-key": key})
            j = json.load(urllib.request.urlopen(req, timeout=90))
            t = "".join(p.get("text", "") for p in j["candidates"][0]["content"]["parts"]).strip()
            if t:
                return t
        except Exception as e:
            print("gemini", m, type(e).__name__, getattr(e, "code", ""))
    return None


def fallback_report(rep):
    pp = rep["paper"]
    pos = pp["open_position"]
    lines = [f"\U0001f4ca USD/JPY \u100a\u1014\u1031 report ({rep['time_jst']} JST)", "",
             f"\u1008\u1031\u1038: {rep['price']} (24\u1014\u102c\u101b\u102e {rep['change_24h']:+.3f})",
             f"\u1021\u1019\u103c\u1004\u1037\u103a/\u1021\u1014\u102d\u1019\u1037\u103a: {rep['high_24h']} / {rep['low_24h']}",
             f"Trend: {rep['trend']} \u00b7 RSI {rep['rsi']}", "",
             f"\U0001f916 Bot A: ${pp['balance']:,.2f}" + (f" \u00b7 {pos['side'].upper()} @ {pos['entry']}" if pos else "") + gate_line(pp.get("scorecard"))]
    for n, b in (rep.get("daily_bots") or {}).items():
        op = b.get("open_position")
        ops = b.get("open_positions")
        extra = (f" \u00b7 {op['side'].upper()} @ {op['entry']} (stop {op['stop']})" if op else "")
        if ops:
            extra = " \u00b7 " + ", ".join(f"{x['pair']} {x['side'].upper()}" for x in ops)
        lines.append(f"\U0001f916 Bot {n}: ${b['balance']:,.2f}" + extra + gate_line(b.get("scorecard")))
    return "\n".join(lines)


def gate_line(sc):
    """short checklist mark, e.g. ' \u00b7 \u27051/4' = 1 of the 4 real-money checks passed"""
    if not sc:
        return ""
    return f" \u00b7 \u2705{sum(1 for v in sc['checks'].values() if v)}/{len(sc['checks'])}"


def evening_report(rep, s):
    now = dt.datetime.now(JST)
    today = now.strftime("%Y-%m-%d")
    forced = os.environ.get("FX_REPORT") == "1"
    if not forced and (now.hour < REPORT_HOUR_JST or now.weekday() >= 5 or s.get("report_day") == today):
        return
    data = {k: rep[k] for k in ("time_jst", "price", "change_24h", "high_24h", "low_24h", "week_change", "trend", "rsi", "atr")}
    pp = rep["paper"]
    data["bot_A_1h"] = {k: pp.get(k) for k in ("balance", "start", "day_pnl", "halted_today", "open_position", "trades_24h", "total_trades", "win_rate", "scorecard")}
    data["real_money_checklist"] = rep.get("real_money_checklist")
    data["bots_B_C_daily"] = rep.get("daily_bots")
    prompt = ("\u1019\u103c\u1014\u103a\u1019\u102c\u101c\u102d\u102f USD/JPY \u100a\u1014\u1031 report \u1010\u1005\u103a\u1001\u102f \u101b\u1031\u1038\u1015\u1031\u1038\u1015\u102b\u104b "
              "Write it in casual, friendly everyday Burmese like an older friend texting (not formal, not AI-sounding), "
              "for a beginner who is learning with PAPER trading only (fake $1000 per bot, no real money). "
              "Max about 1200 characters. Plain text for Telegram (no markdown, no tables, few emojis). Include: "
              "1) today's price, 24h change, high/low and what the trend/RSI roughly mean in one or two simple sentences; "
              "2) each bot (Bot A = 1-hour EMA bot, Bot B and Bot C = daily USD/JPY bots, Bot C+ = Bot C rules on 11 pairs): balance vs $1000, open positions, trades closed in the last 24h, "
              "and how many of the 4 real-money checks it passes (scorecard.checks; it is normal that none pass for months); "
              "3) one short honest lesson line. Never tell the reader to buy or sell with real money, no predictions presented as certain. "
              "End with the line: \u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b\n\nDATA:\n"
              + json.dumps(data, ensure_ascii=False))
    text = gemini_text(prompt) or fallback_report(rep)
    EVENTS.append(("raw", text[:4000], pp["balance"]))
    s["report_day"] = today


def clean_bars(df, min_close=0.0, max_jump=0.10):
    """drop impossible rows and one-bar bad Yahoo ticks, then make sure High/Low contain Open/Close.
    Real crashes (a big move that stays) are kept; only spikes that snap back are removed."""
    df = df.dropna(subset=["Open", "High", "Low", "Close"])
    df = df[(df["High"] >= df["Low"]) & (df["Close"] > min_close) & (df["Open"] > 0) & (df["Low"] > 0)].copy()
    O, H, L, C = df["Open"], df["High"], df["Low"], df["Close"]
    pc, nc = C.shift(), C.shift(-1)
    lg = lambda a, b: np.log(a / b).abs()
    bad = ((lg(C, pc) > max_jump) & (lg(C, nc) > max_jump) & (np.sign(np.log(C / pc)) == np.sign(np.log(C / nc)))).fillna(False)
    bad |= ((lg(O, pc) > max_jump) & (lg(O, C) > max_jump)).fillna(False)
    bad |= (np.log(H / np.maximum(O, C)) > 2 * max_jump) | (np.log(np.minimum(O, C) / L) > 2 * max_jump)
    df = df[~bad].copy()
    df["High"] = df[["High", "Open", "Close"]].max(axis=1)
    df["Low"] = df[["Low", "Open", "Close"]].min(axis=1)
    return df


def load_state():
    if os.path.exists(ST):
        return json.load(open(ST))
    return {"balance": START_BALANCE, "position": None, "last_ts": None,
            "day": None, "day_pnl": 0.0, "halted": False, "trades": []}


def indicators(df):
    c = df["Close"]
    df["ema20"] = c.ewm(span=20, adjust=False).mean()
    df["ema50"] = c.ewm(span=50, adjust=False).mean()
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    df["rsi"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - c.shift()).abs(), (df["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    df["atr"] = tr.rolling(14).mean()
    return df


def step(s, ts, t, r):
        day = ts.tz_convert(JST).strftime("%Y-%m-%d") if ts.tzinfo else ts.strftime("%Y-%m-%d")
        if day != s["day"]:
            s["day"], s["day_pnl"], s["halted"] = day, 0.0, False
        pos = s["position"]
        utc = ts.tz_convert("UTC")
        fri_late = utc.weekday() == 4 and utc.hour >= 19
        if pos:
            sgn = 1 if pos["side"] == "buy" else -1
            # a stop that the price jumped over (gap) is filled at the open, not at the stop price
            if pos["side"] == "buy" and r["Low"] <= pos["stop"]:
                close_pos(s, pos, min(float(r["Open"]), pos["stop"]) - sgn * SPREAD / 2, t, "stop")
            elif pos["side"] == "sell" and r["High"] >= pos["stop"]:
                close_pos(s, pos, max(float(r["Open"]), pos["stop"]) - sgn * SPREAD / 2, t, "stop")
            elif pos["side"] == "buy" and r["High"] >= pos["tp"]:
                close_pos(s, pos, pos["tp"] - sgn * SPREAD / 2, t, "target")
            elif pos["side"] == "sell" and r["Low"] <= pos["tp"]:
                close_pos(s, pos, pos["tp"] - sgn * SPREAD / 2, t, "target")
            elif fri_late:
                close_pos(s, pos, float(r["Close"]) - sgn * SPREAD / 2, t, "weekend")
        no_entry = (utc.weekday() == 4 and utc.hour >= 15) or not (7 <= utc.hour <= 20)
        if not s["position"] and not s["halted"] and not no_entry and not np.isnan(r["atr"]):
            side = None
            if r["ema20"] > r["ema50"] and 50 < r["rsi"] < 70 and r["Close"] > r["ema20"]:
                side = "buy"
            elif r["ema20"] < r["ema50"] and 30 < r["rsi"] < 50 and r["Close"] < r["ema20"]:
                side = "sell"
            if side:
                dist = 1.5 * r["atr"]
                price = float(r["Close"]) + (SPREAD / 2 if side == "buy" else -SPREAD / 2)
                units = RISK_PER_TRADE * price / dist
                s["position"] = {"side": side, "entry": round(price, 3), "units": round(units),
                                 "stop": round(price - dist if side == "buy" else price + dist, 3),
                                 "tp": round(price + 2 * dist if side == "buy" else price - 2 * dist, 3), "ts": t}
                EVENTS.append(("open", s["position"], s["balance"]))
        s["last_ts"] = t


def close_pos(s, pos, price, ts, why):
    pnl_jpy = (price - pos["entry"]) * pos["units"] * (1 if pos["side"] == "buy" else -1)
    pnl = pnl_jpy / price
    s["balance"] = round(s["balance"] + pnl, 2)
    s["day_pnl"] = round(s["day_pnl"] + pnl, 2)
    ensure_stats(s)
    s["trades"].append({"side": pos["side"], "entry": pos["entry"], "exit": round(price, 3),
                        "open": pos["ts"], "close": ts, "pnl": round(pnl, 2), "why": why})
    add_stat(s, round(pnl, 2))
    s["position"] = None
    EVENTS.append(("close", s["trades"][-1], s["balance"]))
    if s["day_pnl"] <= -DAILY_LOSS_LIMIT:
        s["halted"] = True
        EVENTS.append(("halt", None, s["balance"]))


def simulate(df, s):
    for ts, r in df.iloc[60:].iterrows():
        t = ts.isoformat()
        if s["last_ts"] and t <= s["last_ts"]:
            continue
        step(s, ts, t, r)
    return s


# ---------------- daily bots (chosen by train/test research, see fx/research.json) ----------------
SWAP_DIFF = 3.3  # % per year, rough USD-JPY rate gap: long USD earns, short pays
DAILY_BOTS = {
    "B": {"label": "Bot B – နေ့စဉ် Breakout (20)", "kind": "breakout", "n": 20, "stop_atr": 3.0},
    "C": {"label": "Bot C – နေ့စဉ် Trend (EMA20/100)", "kind": "ema", "fast": 20, "slow": 100, "stop_atr": 3.0},
}
# Bot C+ = Bot C's exact rules (not re-tuned) on many pairs, so it gets enough trades to judge. See fx/research2.json.
CPLUS = {"label": "Bot C+ – Bot C စည်းမျဉ်း ငွေကြေး ၁၁ စုံ",
         "kind": "ema", "fast": 20, "slow": 100, "stop_atr": 3.0, "risk": 5.0,
         "pairs": ["USDJPY=X", "EURUSD=X", "GBPUSD=X", "AUDUSD=X", "NZDUSD=X", "USDCAD=X", "USDCHF=X",
                   "EURJPY=X", "GBPJPY=X", "AUDJPY=X", "EURGBP=X"]}
COST_PIPS = {"USDJPY=X": 1.0, "EURUSD=X": 1.0, "GBPUSD=X": 1.5, "AUDUSD=X": 1.5, "NZDUSD=X": 2.0, "USDCAD=X": 2.0,
             "USDCHF=X": 2.0, "EURJPY=X": 2.0, "GBPJPY=X": 3.0, "AUDJPY=X": 2.0, "EURGBP=X": 2.0}
# "ready for real money?" checklist agreed with Ye (all must pass, and even then start tiny)
GATE = {"months": 6, "trades": 30, "pf": 1.3, "max_dd": 100.0}


def pname(t):
    t = t.replace("=X", "")
    return t[:3] + "/" + t[3:] if len(t) == 6 else t


def fp(x, pair="USD/JPY"):
    return f"{x:.3f}" if "JPY" in pair else f"{x:.5f}"


def ensure_stats(a):
    """running totals, so the checklist stays right even after old trades are trimmed from the list"""
    if "stats" not in a:
        a["stats"] = {"n": 0, "wins": 0, "win_sum": 0.0, "loss_sum": 0.0, "eq": 0.0, "peak": 0.0, "dd": 0.0}
        for x in a.get("trades", []):
            add_stat(a, x["pnl"])
    return a["stats"]


def add_stat(a, pnl):
    st = ensure_stats(a)
    st["n"] += 1
    if pnl > 0:
        st["wins"] += 1
        st["win_sum"] = round(st["win_sum"] + pnl, 2)
    else:
        st["loss_sum"] = round(st["loss_sum"] - pnl, 2)
    st["eq"] = round(st["eq"] + pnl, 2)
    st["peak"] = max(st["peak"], st["eq"])
    st["dd"] = round(max(st["dd"], st["peak"] - st["eq"]), 2)


def scorecard(a, today):
    st = ensure_stats(a)
    since = a.get("since") or today
    months = round((dt.date.fromisoformat(today) - dt.date.fromisoformat(since)).days / 30.44, 1)
    pf = round(st["win_sum"] / st["loss_sum"], 2) if st["loss_sum"] > 0 else (99.0 if st["win_sum"] > 0 else None)
    checks = {"months_6": months >= GATE["months"], "trades_30": st["n"] >= GATE["trades"],
              "pf_1.3": (pf or 0) > GATE["pf"], "dd_under_100": st["dd"] < GATE["max_dd"]}
    return {"since": since, "months": months, "trades": st["n"],
            "win_rate": round(100 * st["wins"] / st["n"], 1) if st["n"] else None,
            "profit_factor": pf, "max_drawdown": st["dd"], "checks": checks, "ready": all(checks.values())}


def daily_signal(cfg, d, i):
    C = d["Close"].values
    if cfg["kind"] == "breakout":
        hi = d["High"].rolling(cfg["n"]).max().shift(1).values
        lo = d["Low"].rolling(cfg["n"]).min().shift(1).values
        if np.isnan(hi[i]):
            return 0
        return 1 if C[i] > hi[i] else (-1 if C[i] < lo[i] else 0)
    f = d["Close"].ewm(span=cfg["fast"], adjust=False).mean().values
    sl = d["Close"].ewm(span=cfg["slow"], adjust=False).mean().values
    if i < cfg["slow"]:
        return 0
    return 1 if f[i] > sl[i] else -1


def daily_text(cfg, kind, pos, bal, extra=None, pair="USD/JPY", risk=RISK_PER_TRADE):
    warn = "\n\n⚠️ ငွေတု paper trading ပါ"
    head = "\U0001f916 " + cfg["label"] + "\n"
    side = "\U0001f7e2 BUY (ဝယ်)" if pos["s"] == 1 else "\U0001f534 SELL (ရောင်း)"
    if kind == "open":
        return (head + "\U0001f514 trade ဝင်ပြီ!\n\n" + f"{side} {pair}\n\U0001f4cd ဝင်ဈေး: {fp(pos['e'], pair)}\n"
                f"\U0001f6d1 Stop: {fp(pos['stop'], pair)} (ထိရင် -${risk:g})\n"
                "\U0001f3af Target မရှိဘူး – trend ပြောင်းမှ ထွက်မယ်" + warn)
    pnl, exitp, why = extra
    mark = "✅" if pnl > 0 else "❌"
    whys = {"stop": "Stop ထိလို့", "signal": "Trend ပြောင်းလို့"}
    return (head + f"{mark} trade ပိတ်ပြီ ({whys.get(why, why)}) {'+' if pnl > 0 else '-'}${abs(pnl):.2f}\n\n"
            f"{pair} {'BUY' if pos['s'] == 1 else 'SELL'} {fp(pos['e'], pair)} → {fp(exitp, pair)}\n\U0001f4b0 လက်ကျန်: ${bal:,.2f} (အစ $1,000)" + warn)


def load_daily(ticker, min_close=0.0):
    d = yf.download(ticker, period="2y", interval="1d", progress=False, auto_adjust=False)
    if isinstance(d.columns, pd.MultiIndex):
        d.columns = d.columns.get_level_values(0)
    if len(d) == 0:
        return d
    d = clean_bars(d, min_close)
    c = d["Close"]
    tr = pd.concat([d["High"] - d["Low"], (d["High"] - c.shift()).abs(), (d["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    d["atr"] = tr.rolling(14).mean()
    # only finished candles: a daily candle is dated by its trading day, which ends at 00:00 UTC
    today_utc = dt.datetime.now(dt.timezone.utc).date()
    return d[[x.date() < today_utc for x in d.index]]


def trade_daily(acct, slot, cfg, d, pair, risk, cost, swap):
    """walk the new daily candles for one pair. acct holds balance/trades, slot holds position/last for this pair.
    swap=True: the original USD/JPY account formula (units, swap). swap=False: risk-based P&L (1R = risk dollars)."""
    if d is None or len(d) == 0 or "atr" not in d.columns:
        return
    O, H, L, C, A = (d[k].values for k in ("Open", "High", "Low", "Close", "atr"))
    keys = [x.strftime("%Y-%m-%d") for x in d.index]
    if slot.get("last") is None:
        slot["last"] = keys[-1]  # a new pair starts from today, no back-filled trades
    for i in range(len(d)):
        if keys[i] <= slot["last"]:
            continue
        pos = slot["position"]
        if pos:
            sg = pos["s"]
            if swap:
                acct["balance"] += sg * pos["units"] * SWAP_DIFF / 100 / 365
            hit, why = None, None
            if sg == 1 and L[i] <= pos["stop"]:
                hit, why = min(float(O[i]), pos["stop"]), "stop"
            elif sg == -1 and H[i] >= pos["stop"]:
                hit, why = max(float(O[i]), pos["stop"]), "stop"
            elif daily_signal(cfg, d, i) == -sg:
                hit, why = float(C[i]), "signal"
            if hit is not None:
                ex = hit - sg * cost / 2
                if swap:
                    pnl = (ex - pos["e"]) * pos["units"] * sg / ex
                else:
                    pnl = pos["risk"] * (ex - pos["e"]) * sg / pos["dist"]
                ensure_stats(acct)
                acct["balance"] = round(acct["balance"] + pnl, 2)
                acct["trades"].append({"pair": pair, "side": "buy" if sg == 1 else "sell", "entry": round(pos["e"], 5),
                                       "exit": round(ex, 5), "open": pos["date"], "close": keys[i], "pnl": round(pnl, 2), "why": why})
                add_stat(acct, round(pnl, 2))
                EVENTS.append(("raw", daily_text(cfg, "close", pos, acct["balance"], (pnl, ex, why), pair, risk), acct["balance"]))
                slot["position"] = None
        if slot["position"] is None and not np.isnan(A[i]) and A[i] > 0:
            sig = daily_signal(cfg, d, i)
            if sig:
                e = float(C[i]) + sig * cost / 2
                dist = cfg["stop_atr"] * float(A[i])
                p = {"s": sig, "e": e, "stop": e - sig * dist, "date": keys[i]}
                if swap:
                    p["units"] = risk * e / dist
                else:
                    p["dist"], p["risk"] = dist, risk
                slot["position"] = p
                EVENTS.append(("raw", daily_text(cfg, "open", p, acct["balance"], None, pair, risk), acct["balance"]))
        slot["last"] = keys[i]


def pos_view(p, pair="USD/JPY"):
    return {"pair": pair, "side": "buy" if p["s"] == 1 else "sell", "entry": round(p["e"], 5 if "JPY" not in pair else 3),
            "stop": round(p["stop"], 5 if "JPY" not in pair else 3), "since": p["date"]}


def run_daily(s):
    today = dt.datetime.now(JST).strftime("%Y-%m-%d")
    bots = s.setdefault("daily", {})
    out = {}
    try:
        d = load_daily("USDJPY=X", 50)
    except Exception as e:
        print("USDJPY daily error", type(e).__name__, e)
        d = None
    for name, cfg in DAILY_BOTS.items():
        b = bots.setdefault(name, {"balance": START_BALANCE, "position": None, "last": None, "trades": [], "since": today})
        b.setdefault("since", today)
        if d is not None and len(d) > cfg.get("slow", 0) + 20:
            trade_daily(b, b, cfg, d, "USD/JPY", RISK_PER_TRADE, SPREAD, True)
        b["balance"] = round(b["balance"], 2)
        b["trades"] = b["trades"][-100:]
        out[name] = {"label": cfg["label"], "balance": b["balance"],
                     "open_position": pos_view(b["position"]) if b["position"] else None,
                     "total_trades": ensure_stats(b)["n"], "last_trades": b["trades"][-3:], "scorecard": scorecard(b, today)}
    cp = bots.setdefault("C+", {"balance": START_BALANCE, "pairs": {}, "trades": [], "since": today})
    errors = [] if d is not None else ["USD/JPY (Bot B/C)"]
    first_event = len(EVENTS)
    for t in CPLUS["pairs"]:
        pair = pname(t)
        try:
            dd = d if (t == "USDJPY=X" and d is not None) else load_daily(t)
            if len(dd) < CPLUS["slow"] + 20:
                raise ValueError("only %d candles" % len(dd))
            slot = cp["pairs"].setdefault(pair, {"position": None, "last": None})
            trade_daily(cp, slot, CPLUS, dd, pair, CPLUS["risk"], COST_PIPS.get(t, 2.0) * (0.01 if "JPY" in t else 0.0001), False)
        except Exception as e:
            errors.append(pair)
            print("C+ pair error", pair, type(e).__name__, e)
    # one Telegram message for all C+ trades of this run (11 pairs can trade on the same day)
    cmsgs = [x[1] for x in EVENTS[first_event:]]
    del EVENTS[first_event:]
    if cmsgs:
        head = "\U0001f916 " + CPLUS["label"] + "\n"
        body = "\n\n".join(m.replace(head, "").replace("\n\n\u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b", "").strip() for m in cmsgs)
        tail = (f"\n\n\U0001f4b0 C+ \u101c\u1000\u103a\u1000\u103b\u1014\u103a: ${cp['balance']:,.2f}" +
                "\n\n\u26a0\ufe0f \u1004\u103d\u1031\u1010\u102f paper trading \u1015\u102b")
        parts, cur = [], ""
        for blk in body.split("\n\n"):  # Telegram max is 4096 characters, so split long catch-ups
            if cur and len(cur) + len(blk) > 3300:
                parts.append(cur)
                cur = ""
            cur = (cur + "\n\n" + blk) if cur else blk[:3300]
        parts.append(cur)
        for k, part in enumerate(parts):
            EVENTS.append(("raw", head + part + (tail if k == len(parts) - 1 else ""), cp["balance"]))
    cp["balance"] = round(cp["balance"], 2)
    cp["trades"] = cp["trades"][-300:]
    opens = [pos_view(v["position"], k) for k, v in cp["pairs"].items() if v.get("position")]
    out["C+"] = {"label": CPLUS["label"], "balance": cp["balance"], "open_positions": opens,
                 "open_position": None, "total_trades": ensure_stats(cp)["n"], "last_trades": cp["trades"][-3:],
                 "scorecard": scorecard(cp, today), "pair_errors": errors,
                 "rules": "Bot C rules (EMA20/100, 3xATR stop) on 11 pairs, $5 risk per trade per pair, costs counted, swap not counted",
                 "open_risk_usd": round(CPLUS["risk"] * len(opens), 2)}
    return out


def run():
    try:
        df = yf.download("USDJPY=X", period="30d", interval="1h", progress=False, auto_adjust=False)
    except Exception as e:
        print("hourly download error", type(e).__name__, e, "- nothing changed")
        return
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    if len(df):
        df = clean_bars(df)
    if len(df) < 70:
        print("hourly data missing or too short (Yahoo error / rate limit?):", len(df), "rows - nothing changed")
        return
    df = indicators(df)
    fresh = not os.path.exists(ST)
    bt = simulate(df, {"balance": START_BALANCE, "position": None, "last_ts": None,
                       "day": None, "day_pnl": 0.0, "halted": False, "trades": []})
    s = load_state()
    today = dt.datetime.now(JST).strftime("%Y-%m-%d")
    if not s.get("since"):
        s["since"] = s["trades"][0]["open"][:10] if s.get("trades") else today
    ensure_stats(s)
    done = df.iloc[:-1]  # last hourly candle is still forming
    if fresh:
        s["last_ts"] = done.index[-1].isoformat()
    EVENTS.clear()
    simulate(done, s)
    s["trades"] = s["trades"][-200:]
    utc_day = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    daily_bots = s.get("daily_out")
    tries = s.get("daily_tries", {}) if isinstance(s.get("daily_tries"), dict) else {}
    tries = {utc_day: tries.get(utc_day, 0)}
    retry = bool((daily_bots or {}).get("C+", {}).get("pair_errors")) and tries[utc_day] < 3
    if s.get("daily_run") != utc_day or not daily_bots or retry or os.environ.get("FX_DAILY") == "1":
        tries[utc_day] += 1
        s["daily_tries"] = tries
        try:
            daily_bots = run_daily(s)
            s["daily_as_of"] = dt.datetime.now(JST).strftime("%Y-%m-%d %H:%M")
            s["daily_run"] = utc_day
            s["daily_out"] = daily_bots
        except Exception as e:
            print("daily bots error", type(e).__name__, e)
    last = df.iloc[-1]
    d24 = df[df.index >= df.index[-1] - pd.Timedelta(hours=24)]
    closed = [x for x in s["trades"] if x["close"] >= (df.index[-1] - pd.Timedelta(hours=24)).isoformat()]
    rep = {
        "time_jst": dt.datetime.now(JST).strftime("%Y-%m-%d %H:%M"),
        "price": round(float(last["Close"]), 3),
        "change_24h": round(float(last["Close"] - d24["Close"].iloc[0]), 3),
        "high_24h": round(float(d24["High"].max()), 3), "low_24h": round(float(d24["Low"].min()), 3),
        "week_change": round(float(last["Close"] - df["Close"].iloc[-120]), 3) if len(df) > 120 else None,
        "trend": "up" if last["ema20"] > last["ema50"] else "down",
        "rsi": round(float(last["rsi"]), 1), "atr": round(float(last["atr"]), 3),
        "paper": {"balance": s["balance"], "start": START_BALANCE, "day_pnl": s["day_pnl"],
                  "halted_today": s["halted"], "open_position": s["position"],
                  "trades_24h": closed, "total_trades": s["stats"]["n"],
                  "win_rate": round(100 * s["stats"]["wins"] / s["stats"]["n"], 1) if s["stats"]["n"] else None,
                  "scorecard": scorecard(s, today),
                  "role": "control bot: 2-year test showed no edge, kept running only to compare against B/C/C+",
                  "backtest_30d": {"trades": len(bt["trades"]), "pnl": round(bt["balance"] - START_BALANCE, 2),
                                   "win_rate": round(100 * sum(1 for x in bt["trades"] if x["pnl"] > 0) / len(bt["trades"]), 1) if bt["trades"] else None},
                  "rules": "EMA20/EMA50 trend + RSI, stop 1.5xATR, target 3xATR, $10 risk/trade, stop for the day at -$30, spread 0.3 pip counted, entries only 16:00-05:59 JST (London/NY), closes before the weekend", "backtest_2y": "about break-even over ~2.7 years (profit factor ~1.0, max drawdown ~$330-530): no proven edge"},
        "daily_bots": daily_bots,
        "daily_bots_updated_jst": s.get("daily_as_of"),
        "daily_bots_note": "Bot B (daily 20-day breakout, 3xATR stop) and Bot C (daily EMA20/100 trend, 3xATR stop) each start with $1000 fake money, $10 risk/trade, swap counted. Research: profitable on 2010-2019 (train) AND 2020-2026 (unseen test), but only ~3 trades per year and helped by the strong 2021-2024 USD/JPY uptrend. Bot C+ runs Bot C's exact rules on 11 pairs ($5 risk each) to collect enough trades; fx/research2.json tests those rules on all 11 pairs since 2010.",
        "real_money_checklist": "ALL of: >=6 months of paper trading, >=30 closed trades, profit factor > 1.3, max drawdown < $100 (10%, measured on closed trades; open trades can add more). Even then: tiny size only. Not financial advice.",
    }
    evening_report(rep, s)
    json.dump(s, open(ST, "w"), indent=1)
    json.dump(rep, open("fx/report.json", "w"), ensure_ascii=False, indent=1)
    print(json.dumps(rep, indent=1))
    send_alerts(rep)


if __name__ == "__main__":
    os.makedirs("fx", exist_ok=True)
    run()

