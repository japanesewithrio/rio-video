"""Robustness test: do the daily Bot B / Bot C rules work on OTHER currency pairs too, with NO re-tuning?
Parameters are frozen (picked on USD/JPY 2010-2019 only). If a rule only works on USD/JPY it was probably luck.
Results are in R (1R = the money lost when the stop is hit). Stops that gap are filled at the open (realistic).
Swap/carry is NOT counted here. Paper research only - no real money."""
import json, os
import numpy as np, pandas as pd

PAIRS = ["USDJPY=X", "EURUSD=X", "GBPUSD=X", "AUDUSD=X", "NZDUSD=X", "USDCAD=X", "USDCHF=X",
         "EURJPY=X", "GBPJPY=X", "AUDJPY=X", "EURGBP=X"]
# cost per round trip in pips (spread + slippage, on the cautious side for a retail account)
COST_PIPS = {"USDJPY=X": 1.0, "EURUSD=X": 1.0, "GBPUSD=X": 1.5, "AUDUSD=X": 1.5, "NZDUSD=X": 2.0, "USDCAD=X": 2.0,
             "USDCHF=X": 2.0, "EURJPY=X": 2.0, "GBPJPY=X": 3.0, "AUDJPY=X": 2.0, "EURGBP=X": 2.0}
RULES = {
    "C_ema20_100": {"kind": "ema", "fast": 20, "slow": 100, "stop_atr": 3.0},
    "B_breakout20": {"kind": "breakout", "n": 20, "stop_atr": 3.0},
}
START = "2010-01-01"
SPLIT = "2018-01-01"
RISK_USD = 5.0  # what Bot C+ risks per trade per pair


def pip(t):
    return 0.01 if "JPY" in t else 0.0001


def clean(df):
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.dropna(subset=["Open", "High", "Low", "Close"])
    df = df[(df["High"] >= df["Low"]) & (df["Close"] > 0) & (df["Open"] > 0) & (df["Low"] > 0)].copy()
    n0 = len(df)
    O, H, L, C = df["Open"], df["High"], df["Low"], df["Close"]
    pc, nc = C.shift(), C.shift(-1)
    lg = lambda a, b: np.log(a / b).abs()
    # only one-bar spikes that snap back are bad ticks; real crashes (a move that stays) are kept
    bad = ((lg(C, pc) > 0.10) & (lg(C, nc) > 0.10) & (np.sign(np.log(C / pc)) == np.sign(np.log(C / nc)))).fillna(False)
    bad |= ((lg(O, pc) > 0.10) & (lg(O, C) > 0.10)).fillna(False)
    bad |= (np.log(H / np.maximum(O, C)) > 0.20) | (np.log(np.minimum(O, C) / L) > 0.20)
    df = df[~bad].copy()
    df.attrs["bad_ticks_dropped"] = n0 - len(df)
    df["High"] = df[["High", "Open", "Close"]].max(axis=1)
    df["Low"] = df[["Low", "Open", "Close"]].min(axis=1)
    c = df["Close"]
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - c.shift()).abs(), (df["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    df["atr"] = tr.rolling(14).mean()
    return df


def signals(df, cfg):
    C = df["Close"].values
    if cfg["kind"] == "breakout":
        hi = df["High"].rolling(cfg["n"]).max().shift(1).values
        lo = df["Low"].rolling(cfg["n"]).min().shift(1).values
        out = np.where(C > hi, 1, np.where(C < lo, -1, 0))
        out[np.isnan(hi)] = 0
        return out
    f = df["Close"].ewm(span=cfg["fast"], adjust=False).mean().values
    s = df["Close"].ewm(span=cfg["slow"], adjust=False).mean().values
    out = np.where(f > s, 1, -1)
    out[: cfg["slow"]] = 0
    return out


def backtest(df, cfg, cost):
    """Same logic as the live daily bots: decide on the close, stop = stop_atr*ATR, exit on stop or opposite signal.
    Returns a list of (exit_date, R)."""
    O, H, L, C, A = (df[k].values for k in ("Open", "High", "Low", "Close", "atr"))
    sig = signals(df, cfg)
    idx = df.index
    pos, trades = None, []
    for i in range(len(df)):
        if pos:
            s = pos["s"]
            ex = None
            if s == 1 and L[i] <= pos["stop"]:
                ex = min(O[i], pos["stop"])
            elif s == -1 and H[i] >= pos["stop"]:
                ex = max(O[i], pos["stop"])
            elif sig[i] == -s:
                ex = C[i]
            if ex is not None:
                r = ((ex - pos["e"]) * s - cost) / pos["dist"]
                trades.append((idx[i], float(r)))
                pos = None
        if pos is None and not np.isnan(A[i]) and A[i] > 0 and sig[i]:
            dist = cfg["stop_atr"] * A[i]
            pos = {"s": int(sig[i]), "e": C[i], "dist": dist, "stop": C[i] - sig[i] * dist}
    return trades


def stats(trades, years):
    rs = np.array([r for _, r in trades], dtype=float)
    if len(rs) == 0:
        return {"trades": 0, "R": 0.0, "R_per_year": 0.0, "pf": None, "win%": None, "max_dd_R": 0.0, "worst_R": None, "big_losses": 0}
    eq = np.cumsum(rs)
    dd = float(np.max(np.maximum.accumulate(np.concatenate([[0], eq]))[1:] - eq))
    w, l = rs[rs > 0].sum(), -rs[rs <= 0].sum()
    return {"trades": int(len(rs)), "R": round(float(rs.sum()), 1), "R_per_year": round(float(rs.sum()) / max(years, 0.1), 2),
            "pf": round(float(w / l), 2) if l > 0 else None, "win%": round(100 * float((rs > 0).mean()), 1),
            "max_dd_R": round(dd, 1), "worst_R": round(float(rs.min()), 2), "big_losses": int((rs < -2).sum())}


def portfolio(all_trades, first, last):
    """All pairs traded together, each trade risking RISK_USD. Drawdown measured on closed trades, by date."""
    if not all_trades:
        return {"trades": 0}
    s = pd.Series([r for _, r in all_trades], index=pd.DatetimeIndex([d for d, _ in all_trades])).sort_index()
    daily = s.groupby(s.index.normalize()).sum() * RISK_USD
    eq = daily.cumsum()
    dd = float((eq.cummax().clip(lower=0) - eq).max())
    yearly = daily.groupby(daily.index.year).sum().round(1)
    years = max((last - first).days / 365.25, 0.1)
    rs = s.values
    w, l = rs[rs > 0].sum(), -rs[rs <= 0].sum()
    return {"trades": int(len(s)), "trades_per_year": round(len(s) / years, 1), "pnl_usd": round(float(daily.sum()), 1),
            "pnl_usd_per_year": round(float(daily.sum()) / years, 1), "pf": round(float(w / l), 2) if l > 0 else None,
            "max_dd_usd": round(dd, 1), "losing_years": int((yearly < 0).sum()), "years": int(len(yearly)),
            "worst_year_usd": round(float(yearly.min()), 1), "by_year_usd": {str(k): float(v) for k, v in yearly.items()}}


def verdict(per_pair, port, port_a, port_b):
    good = sum(1 for p in per_pair.values() if p["all"]["trades"] and p["all"]["R"] > 0)
    both = sum(1 for p in per_pair.values() if p["before_2018"]["R"] > 0 and p["from_2018"]["R"] > 0)
    n = len(per_pair)
    ok = (n > 0 and good >= 0.6 * n and (port.get("pf") or 0) > 1.2 and port.get("pnl_usd", 0) > 0
          and (port_a.get("pf") or 0) > 1.0 and (port_b.get("pf") or 0) > 1.0)
    return {"pairs_tested": n, "pairs_profitable": good, "pairs_profitable_in_both_halves": both,
            "pass": bool(ok), "rule": "pass = profitable on >=60% of pairs AND portfolio profit factor > 1.2 overall "
                                      "AND portfolio profit factor > 1.0 both before and from 2018"}


def run_rule(data, cfg, with_subsets=True):
    per_pair, all_tr = {}, []
    firsts, lasts = [], []
    for t, df in data.items():
        tr = backtest(df, cfg, COST_PIPS.get(t, 2.0) * pip(t))
        first, last = df.index[0], df.index[-1]
        firsts.append(first)
        lasts.append(last)
        yrs = (last - first).days / 365.25
        a = [x for x in tr if x[0] < pd.Timestamp(SPLIT, tz=x[0].tz)]
        b = [x for x in tr if x[0] >= pd.Timestamp(SPLIT, tz=x[0].tz)]
        split_yrs = (pd.Timestamp(SPLIT, tz=first.tz) - first).days / 365.25
        per_pair[t.replace("=X", "")] = {"all": stats(tr, yrs), "before_2018": stats(a, split_yrs),
                                         "from_2018": stats(b, yrs - split_yrs)}
        all_tr += [(d.tz_localize(None) if d.tzinfo else d, r) for d, r in tr]
    if not firsts:
        return {"per_pair": {}, "portfolio": {"trades": 0}, "verdict": verdict({}, {}, {}, {})}
    lo, hi, sp = min(firsts).tz_localize(None) if min(firsts).tzinfo else min(firsts), max(lasts), pd.Timestamp(SPLIT)
    hi = hi.tz_localize(None) if hi.tzinfo else hi
    port = portfolio(all_tr, lo, hi)
    pa = portfolio([x for x in all_tr if x[0] < sp], lo, sp)
    pb = portfolio([x for x in all_tr if x[0] >= sp], sp, hi)
    out = {"per_pair": per_pair, "portfolio": port, "portfolio_before_2018": pa, "portfolio_from_2018": pb,
           "verdict": verdict(per_pair, port, pa, pb)}
    if with_subsets:
        # USD/JPY was used to pick the rules, and JPY crosses move with it: check without them too
        ex = {t: v for t, v in data.items() if t != "USDJPY=X"}
        nj = {t: v for t, v in data.items() if "JPY" not in t}
        out["without_usdjpy"] = {k: v for k, v in run_rule(ex, cfg, False).items() if k in ("portfolio", "verdict")}
        out["non_jpy_pairs_only"] = {k: v for k, v in run_rule(nj, cfg, False).items() if k in ("portfolio", "verdict")}
    return out


DROPPED = {}


def load_all():
    import yfinance as yf
    data = {}
    for t in PAIRS:
        try:
            df = clean(yf.download(t, start=START, interval="1d", progress=False, auto_adjust=False))
            if len(df) > 500:
                data[t] = df
            else:
                DROPPED[t.replace("=X", "")] = "only %d candles" % len(df)
        except Exception as e:
            DROPPED[t.replace("=X", "")] = "download failed: %s" % type(e).__name__
    print("dropped:", DROPPED)
    return data


def main(data=None, out_path="fx/research2.json"):
    data = load_all() if data is None else data
    out = {"note": "Frozen Bot B/C rules on many pairs, no re-tuning. R = multiples of the risk per trade. "
                   "Costs counted, gapped stops filled at the open, one-bar bad ticks (>10% spikes that snap back) removed. "
                   "Swap/carry NOT counted (it can change a pair's result either way, since these bots hold for months). "
                   "Drawdown is on closed trades only; open trades can make the real drawdown bigger. "
                   "USD/JPY 2010-2019 was used to choose the rules, so see without_usdjpy / non_jpy_pairs_only. Paper research only.",
           "pairs_dropped": dict(DROPPED),
           "bad_ticks_dropped": {t.replace("=X", ""): int(v.attrs.get("bad_ticks_dropped", 0)) for t, v in data.items()},
           "period_start": START, "split": SPLIT, "risk_usd_per_trade": RISK_USD,
           "pairs": [t.replace("=X", "") for t in data], "rules": {}}
    for name, cfg in RULES.items():
        out["rules"][name] = {"params": cfg, **run_rule(data, cfg)}
    d = os.path.dirname(out_path)
    if d:
        os.makedirs(d, exist_ok=True)
    json.dump(out, open(out_path, "w"), indent=1)
    for name, r in out["rules"].items():
        print(name, r["verdict"], r["portfolio"])
        for p, v in r["per_pair"].items():
            print("  ", p, v["all"], "| <2018 R", v["before_2018"]["R"], "| >=2018 R", v["from_2018"]["R"])
    return out


if __name__ == "__main__":
    main()
