"""Strategy research for the USD/JPY paper bot: pick parameters on TRAIN data only, judge on unseen TEST data."""
import json, os, itertools
import numpy as np, pandas as pd, yfinance as yf

RISK = 10.0
SPREAD = 0.003
# rough USD-JPY policy-rate differential (% per year) for swap estimate; long USD earns, short pays
DIFF = {2010: 0.2, 2011: 0.2, 2012: 0.2, 2013: 0.2, 2014: 0.2, 2015: 0.3, 2016: 0.6, 2017: 1.2, 2018: 2.0,
        2019: 2.1, 2020: 0.4, 2021: 0.2, 2022: 2.0, 2023: 5.0, 2024: 5.0, 2025: 4.0, 2026: 3.3}


def load(interval, period):
    df = yf.download("USDJPY=X", period=period, interval=interval, progress=False, auto_adjust=False)
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.dropna(subset=["Close"])
    df = df[(df["High"] >= df["Low"]) & (df["Close"] > 50)]
    c = df["Close"]
    tr = pd.concat([df["High"] - df["Low"], (df["High"] - c.shift()).abs(), (df["Low"] - c.shift()).abs()], axis=1).max(axis=1)
    df["atr"] = tr.rolling(14).mean()
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    df["rsi"] = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    return df


def backtest(df, signal, stop_atr, tp_atr=None, trail_atr=None, swap=False, bars_per_day=1, sessions=False):
    """signal(i) -> +1/-1/0 using data up to bar i (enter at close of bar i)."""
    bal, pos, trades, curve = 1000.0, None, [], []
    H, L, C, A = df["High"].values, df["Low"].values, df["Close"].values, df["atr"].values
    idx = df.index
    for i in range(len(df)):
        if pos:
            s = pos["s"]
            if swap:
                bal += s * pos["units"] * DIFF.get(idx[i].year, 2.0) / 100 / 365 / bars_per_day
            hit = None
            if (s == 1 and L[i] <= pos["stop"]) or (s == -1 and H[i] >= pos["stop"]):
                hit = pos["stop"]
            elif pos["tp"] is not None and ((s == 1 and H[i] >= pos["tp"]) or (s == -1 and L[i] <= pos["tp"])):
                hit = pos["tp"]
            else:
                sig = signal(i)
                if sig == -s:
                    hit = C[i]
            if hit is not None:
                ex = hit - s * SPREAD / 2
                pnl = (ex - pos["e"]) * pos["units"] * s / ex
                bal += pnl
                trades.append((idx[i], pnl))
                pos = None
            elif trail_atr and not np.isnan(A[i]):
                ns = C[i] - s * trail_atr * A[i]
                if (ns - pos["stop"]) * s > 0:
                    pos["stop"] = ns
        if pos is None and not np.isnan(A[i]) and A[i] > 0:
            ok = True
            if sessions:
                h = idx[i].tz_convert("UTC").hour if idx[i].tzinfo else idx[i].hour
                ok = 7 <= h <= 20
            sig = signal(i) if ok else 0
            if sig:
                e = C[i] + sig * SPREAD / 2
                dist = stop_atr * A[i]
                pos = {"s": sig, "e": e, "units": RISK * e / dist, "stop": e - sig * dist,
                       "tp": (e + sig * tp_atr * A[i]) if tp_atr else None}
        curve.append(bal)
    curve = np.array(curve)
    dd = float((np.maximum.accumulate(curve) - curve).max()) if len(curve) else 0
    w = sum(p for _, p in trades if p > 0)
    l = -sum(p for _, p in trades if p <= 0)
    yrs = max((idx[-1] - idx[0]).days / 365.25, 0.1)
    return {"trades": len(trades), "pnl": round(bal - 1000, 1), "pnl_per_year": round((bal - 1000) / yrs, 1),
            "pf": round(w / l, 2) if l else None, "win%": round(100 * sum(1 for _, p in trades if p > 0) / max(len(trades), 1), 1),
            "max_dd": round(dd, 1)}


def S_ema(df, fast, slow, long_only=False):
    f = df["Close"].ewm(span=fast, adjust=False).mean().values
    s = df["Close"].ewm(span=slow, adjust=False).mean().values
    def sig(i):
        if i < slow:
            return 0
        v = 1 if f[i] > s[i] else -1
        return 0 if (long_only and v < 0) else v
    return sig


def S_donchian(df, n, long_only=False):
    hi = df["High"].rolling(n).max().shift(1).values
    lo = df["Low"].rolling(n).min().shift(1).values
    C = df["Close"].values
    def sig(i):
        if np.isnan(hi[i]):
            return 0
        if C[i] > hi[i]:
            return 1
        if C[i] < lo[i] and not long_only:
            return -1
        return 0
    return sig


def S_pullback(df):  # current hourly bot
    c = df["Close"]
    e20 = c.ewm(span=20, adjust=False).mean().values
    e50 = c.ewm(span=50, adjust=False).mean().values
    r, C = df["rsi"].values, c.values
    def sig(i):
        if e20[i] > e50[i] and 50 < r[i] < 70 and C[i] > e20[i]:
            return 1
        if e20[i] < e50[i] and 30 < r[i] < 50 and C[i] < e20[i]:
            return -1
        return 0
    return sig


def split(df, frac):
    k = int(len(df) * frac)
    return df.iloc[:k], df.iloc[k:]


def study(name, df, make_sig, grid, bars_per_day, frac, extra=None):
    extra = extra or {}
    train, test = split(df, frac)
    best, best_key = None, None
    rows = []
    for params in grid:
        sp, bp = params
        rtr = backtest(train, make_sig(train, **sp), bars_per_day=bars_per_day, **bp, **extra)
        rows.append((rtr, params))
        score = (rtr["pf"] or 0) if rtr["trades"] >= 20 else 0
        if best is None or score > best:
            best, best_key = score, params
    sp, bp = best_key
    rtr = backtest(train, make_sig(train, **sp), bars_per_day=bars_per_day, **bp, **extra)
    rte = backtest(test, make_sig(test, **sp), bars_per_day=bars_per_day, **bp, **extra)
    return {"name": name, "params": {**sp, **bp, **extra}, "train": rtr, "test": rte,
            "train_period": f"{train.index[0].date()}..{train.index[-1].date()}",
            "test_period": f"{test.index[0].date()}..{test.index[-1].date()}"}


def main():
    out = []
    d = load("1d", "max")
    d = d[d.index >= "2010-01-01"]
    frac = 0.6
    stops = [{"stop_atr": 2.0, "trail_atr": 3.0}, {"stop_atr": 3.0, "trail_atr": 3.0}, {"stop_atr": 3.0, "trail_atr": None},
             {"stop_atr": 2.0, "tp_atr": 4.0}]
    for lo in (False, True):
        for sw in (True,):
            g = [({"fast": f, "slow": s, "long_only": lo}, b) for f, s in [(10, 50), (20, 100), (50, 200)] for b in stops]
            out.append(study(f"daily_ema_trend{'_longonly' if lo else ''}", d, S_ema, g, 1, frac, {"swap": sw}))
            g = [({"n": n, "long_only": lo}, b) for n in (20, 55, 100) for b in stops]
            out.append(study(f"daily_breakout{'_longonly' if lo else ''}", d, S_donchian, g, 1, frac, {"swap": sw}))
    h = load("1h", "730d")
    g = [({}, {"stop_atr": 1.5, "tp_atr": t, "sessions": True}) for t in (2.25, 3.0, 4.5)]
    out.append(study("hourly_pullback_current", h, S_pullback, g, 24, frac, {"swap": True}))
    g = [({"n": n}, {"stop_atr": s, "trail_atr": s, "sessions": True}) for n in (24, 48, 120) for s in (2.0, 3.0)]
    out.append(study("hourly_breakout", h, S_donchian, g, 24, frac, {"swap": True}))
    os.makedirs("fx", exist_ok=True)
    json.dump(out, open("fx/research.json", "w"), indent=1, default=str)
    for r in out:
        print(r["name"], r["params"], "TRAIN", r["train"], "TEST", r["test"])


if __name__ == "__main__":
    main()
