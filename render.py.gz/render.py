"""Render a vertical listening video for Learn with Rio from a job JSON.

Job JSON fields: key, title, script ("Rio: ..." lines), transcript (Telegram HTML),
audio_b64 (base64 WAV).  Output: videos/<key>.mp4
"""
import base64, html, json, os, re, subprocess, sys, tempfile
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 1080, 1920
HERE = os.path.dirname(os.path.abspath(__file__))
FONT_DIR = os.environ.get("FONT_DIR", os.path.join(HERE, "fonts"))
JP_BOLD = os.path.join(FONT_DIR, "MPLUSRounded1c-Bold.ttf")
JP_MED = os.path.join(FONT_DIR, "MPLUSRounded1c-Medium.ttf")
MM = os.path.join(FONT_DIR, "NotoSansMyanmar.ttf")
BG = os.environ.get("BG_IMAGE", os.path.join(HERE, "rio_bg.jpg"))

COL = {"Rio": (120, 190, 255), "Yui": (255, 150, 200)}
EMOJI = re.compile("[\U0001F000-\U0001FAFF\u2600-\u27bf\ufe0f\u200d\U0001F1E6-\U0001F1FF]")


def font(path, size, weight=None):
    f = ImageFont.truetype(path, size, layout_engine=ImageFont.Layout.RAQM)
    if weight is not None:
        try:
            f.set_variation_by_axes([weight, 100])
        except Exception:
            pass
    return f


def clean(t):
    t = re.sub(r"<[^>]+>", "", t or "")
    return EMOJI.sub("", html.unescape(t)).strip()


def parse_turns(transcript, script):
    """Return list of dicts: who, jp, kana, mm (one per spoken line)."""
    turns = []
    body = transcript
    m = re.search(r"<blockquote[^>]*>(.*?)</blockquote>", transcript, re.S)
    if m:
        body = m.group(1)
    for block in re.split(r"\n\s*\n", body):
        mm = re.search(r"<b>\s*(Rio|Yui)\s*:?\s*</b>\s*:?\s*(.+)", block)
        if not mm:
            continue
        who, jp = mm.group(1), clean(mm.group(2).split("\n")[0])
        kana = re.search(r"<i>(.*?)</i>", block, re.S)
        bur = re.search(r"<tg-spoiler>(.*?)</tg-spoiler>", block, re.S)
        if not bur:
            bur = re.search(r"\U0001F1F2\U0001F1F2\s*(.+)", block)
        turns.append({"who": who, "jp": jp,
                      "kana": clean(kana.group(1)) if kana else "",
                      "mm": clean(bur.group(1)) if bur else ""})
    # fall back to the TTS script if the transcript could not be parsed
    lines = [l.strip() for l in script.splitlines() if re.match(r"\s*(Rio|Yui)\s*:", l)]
    if len(turns) != len(lines) and lines:
        by_jp = {t["jp"]: t for t in turns}
        turns = []
        for l in lines:
            who, jp = l.split(":", 1)
            jp = jp.strip()
            t = by_jp.get(jp, {})
            turns.append({"who": who.strip(), "jp": jp, "kana": t.get("kana", ""), "mm": t.get("mm", "")})
    return turns


def parse_point(transcript):
    first = ""
    m = re.search(r"\u6559\u79d1\u66f8[^\n]*", transcript)
    if m:
        first = clean(m.group(0))
    pts = re.findall(r"\U0001F4D8([^\n]+)", transcript)
    warn = re.search(r"\u26a0\ufe0f?([^\n]+)", transcript)
    return first, [clean(p) for p in pts[1:3]], clean(warn.group(1)) if warn else ""


MYA = re.compile(r"[\u1000-\u109F\uAA60-\uAA7F\uA9E0-\uA9FF]")


def runs(text, fnt, alt):
    """Split text into (segment, font) runs: Myanmar chars use the MM font, the rest the JP font."""
    mm_font = fnt if fnt.path.endswith("Myanmar.ttf") else None
    if mm_font is None:
        return [(text, fnt)]
    out, cur, cur_f = [], "", None
    for ch in text:
        f = mm_font if (MYA.match(ch) or ch in " .,!?'\"()-:") else alt
        if cur and f is not cur_f:
            out.append((cur, cur_f)); cur = ""
        cur += ch; cur_f = f
    if cur:
        out.append((cur, cur_f))
    return out


def tlen(draw, text, fnt, alt):
    return sum(draw.textlength(t, font=f) for t, f in runs(text, fnt, alt))


def wrap(draw, text, fnt, maxw, alt):
    out, line = [], ""
    tokens = re.findall(r"\S+\s*", text) if MYA.search(text) else list(text)
    for tok in tokens:
        test = line + tok
        if tlen(draw, test.rstrip(), fnt, alt) <= maxw or not line:
            line = test
        else:
            out.append(line.rstrip())
            line = tok
    if line.strip():
        out.append(line.rstrip())
    return out


def block(draw, y, text, fnt, fill, maxw=940, gap=14, center=True):
    alt = font(JP_MED, max(int(fnt.size * 0.9), 10))
    asc_ref = fnt.getbbox("A\u1000")[3]
    for ln in wrap(draw, text, fnt, maxw, alt):
        w = tlen(draw, ln, fnt, alt)
        x = (W - w) / 2 if center else 70
        for seg, f in runs(ln, fnt, alt):
            draw.text((x, y + asc_ref), seg, font=f, fill=fill, anchor="ls")
            x += draw.textlength(seg, font=f)
        y += int(fnt.size * (1.9 if MYA.search(ln) else 1.25)) + gap - 14
    return y


def base():
    if not os.path.exists(BG):
        g = Image.linear_gradient("L").resize((W, H))
        img = Image.merge("RGB", [g.point(lambda v: 40 + v // 3), g.point(lambda v: 20 + v // 6), g.point(lambda v: 90 + v // 3)])
        return img.convert("RGBA")
    img = Image.open(BG).convert("RGB").resize((W, H))
    img = img.filter(ImageFilter.GaussianBlur(2))
    shade = Image.new("RGBA", (W, H), (15, 5, 40, 120))
    img = Image.alpha_composite(img.convert("RGBA"), shade)
    return img


def card(img, top, bottom):
    ov = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(ov).rounded_rectangle([40, top, W - 40, bottom], 40, fill=(20, 8, 50, 205))
    return Image.alpha_composite(img, ov)


def header(d, title, sub):
    d.text((W / 2, 70), "LISTENING  |  Learn with Rio", font=font(JP_BOLD, 38), fill=(255, 214, 245), anchor="mt")
    y = block(d, 140, title, font(JP_BOLD, 72), (255, 255, 255))
    if sub:
        block(d, y + 6, sub, font(JP_MED, 40), (255, 224, 102))


def frame_turn(title, sub, t, idx, n):
    img = base()
    img = card(img, 360, 1640)
    d = ImageDraw.Draw(img)
    header(d, title, sub)
    col = COL.get(t["who"], (255, 255, 255))
    d.rounded_rectangle([W / 2 - 110, 400, W / 2 + 110, 480], 40, fill=col)
    d.text((W / 2, 440), t["who"], font=font(JP_BOLD, 48), fill=(20, 8, 50), anchor="mm")
    jp_size = 76 if len(t["jp"]) <= 22 else 64 if len(t["jp"]) <= 36 else 54
    y = block(d, 530, t["jp"], font(JP_BOLD, jp_size), (255, 255, 255), gap=18)
    if t["kana"] and t["kana"] != t["jp"]:
        y = block(d, y + 24, t["kana"], font(JP_MED, 42), (255, 214, 245))
    if t["mm"]:
        block(d, y + 40, t["mm"], font(MM, 46 if len(t["mm"]) < 70 else 40, 600), (255, 224, 102), gap=30)
    # progress dots
    for i in range(n):
        x = W / 2 + (i - (n - 1) / 2) * 44
        d.ellipse([x - 11, 1590 - 11, x + 11, 1590 + 11], fill=col if i == idx else (120, 110, 150))
    return img.convert("RGB")


def frame_intro(title, sub):
    img = base()
    img = card(img, 600, 1100)
    d = ImageDraw.Draw(img)
    header(d, title, "")
    d.text((W / 2, 700), "\u3053\u306e\u4f1a\u8a71\u3001\u805e\u304d\u53d6\u308c\u308b\uff1f", font=font(JP_BOLD, 60), fill=(255, 255, 255), anchor="mt")
    if sub:
        block(d, 820, sub, font(JP_MED, 46), (255, 224, 102))
    d.text((W / 2, 980), "\u1014\u102c\u1038\u1011\u1031\u102c\u1004\u103a\u1015\u103c\u102e\u1038 \u1001\u1014\u1037\u103a\u1019\u103e\u1014\u103a\u1038\u1000\u103c\u100a\u1037\u103a\u1014\u1031\u102c\u103a", font=font(MM, 44, 600), fill=(255, 214, 245), anchor="mt")
    return img.convert("RGB")


def frame_outro(title, sub, points, warn):
    img = base()
    img = card(img, 480, 1560)
    d = ImageDraw.Draw(img)
    header(d, title, "")
    y = 520
    d.text((W / 2, y), "POINT", font=font(JP_BOLD, 52), fill=(255, 214, 245), anchor="mt")
    y += 90
    if sub:
        y = block(d, y, sub, font(JP_BOLD, 50), (255, 255, 255)) + 20
    for p in points:
        y = block(d, y, p, font(MM, 38, 500), (255, 224, 102), gap=24) + 16
    if warn:
        block(d, y + 10, "(!) " + warn, font(MM, 36, 500), (255, 190, 190), gap=22)
    d.text((W / 2, 1640), "Follow  Learn with Rio \u2661", font=font(JP_BOLD, 56), fill=(255, 255, 255), anchor="mt")
    return img.convert("RGB")


def silences(wav):
    out = subprocess.run(["ffmpeg", "-hide_banner", "-i", wav, "-af", "silencedetect=noise=-35dB:d=0.18", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    starts = [float(x) for x in re.findall(r"silence_start: (-?[\d.]+)", out)]
    ends = [float(x) for x in re.findall(r"silence_end: ([\d.]+)", out)]
    return list(zip(starts, ends))


def duration(wav):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", wav],
                         capture_output=True, text=True).stdout
    return float(out.strip())


def split_points(wav, turns):
    """Boundaries between turns: the n-1 longest pauses, falling back to text length."""
    total = duration(wav)
    n = len(turns)
    sil = [(s, e) for s, e in silences(wav) if 0.3 < s < total - 0.3]
    if len(sil) >= n - 1:
        best = sorted(sorted(sil, key=lambda p: p[1] - p[0], reverse=True)[: n - 1])
        return [(s + e) / 2 for s, e in best], total
    lens = [max(len(t["jp"]), 3) for t in turns]
    acc, pts = 0, []
    for l in lens[:-1]:
        acc += l
        pts.append(total * acc / sum(lens))
    return pts, total


def section(raw, name):
    m = re.search(r"===" + name + r"===\s*(.*?)\s*(?====[A-Z]+===|$)", raw, re.S)
    return m.group(1).strip() if m else ""


def load_job(src):
    """src is either a .json job or a .txt with ===TITLE=== / ===SCRIPT=== / ===TRANSCRIPT=== sections."""
    raw = open(src, encoding="utf-8").read()
    if src.endswith(".json"):
        return json.loads(raw)
    return {"title": section(raw, "TITLE"), "script": section(raw, "SCRIPT"),
            "transcript": section(raw, "TRANSCRIPT")}


def main(job_path, wav, out_path):
    job = load_job(job_path)
    tmp = tempfile.mkdtemp()
    if not wav:
        wav = os.path.join(tmp, "a.wav")
        open(wav, "wb").write(base64.b64decode(job["audio_b64"]))
    title = clean(job.get("title", ""))
    turns = parse_turns(job.get("transcript", ""), job.get("script", ""))
    sub, points, warn = parse_point(job.get("transcript", ""))
    if "textbook" in sub:
        sub = ""
    pts, total = split_points(wav, turns)
    INTRO, OUTRO = 2.5, 5.0
    bounds = [0.0] + pts + [total]
    segs = [(frame_intro(title, sub), INTRO)]
    for i, t in enumerate(turns):
        segs.append((frame_turn(title, sub, t, i, len(turns)), bounds[i + 1] - bounds[i]))
    segs.append((frame_outro(title, sub, points, warn), OUTRO))
    lst = os.path.join(tmp, "list.txt")
    with open(lst, "w") as f:
        for i, (im, dur) in enumerate(segs):
            p = os.path.join(tmp, f"f{i:02d}.png")
            im.save(p)
            f.write(f"file '{p}'\nduration {max(dur, 0.5):.3f}\n")
        f.write(f"file '{p}'\n")
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                    "-f", "concat", "-safe", "0", "-i", lst,
                    "-itsoffset", str(INTRO), "-i", wav,
                    "-filter_complex", f"[1:a]apad=pad_dur={OUTRO}[a]",
                    "-map", "0:v", "-map", "[a]", "-r", "30", "-c:v", "libx264", "-preset", "veryfast",
                    "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-shortest",
                    "-movflags", "+faststart", out_path], check=True)
    print("rendered", out_path, "turns", len(turns), "audio", round(total, 1))


if __name__ == "__main__":
    # render.py JOB [WAV] OUT
    args = sys.argv[1:]
    if len(args) == 2:
        main(args[0], None, args[1])
    else:
        main(args[0], args[1], args[2])
