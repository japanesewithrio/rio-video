"""research3: test several classic strategy families on 11 FX pairs since 2010, the same honest way as research2.
All parameters are fixed in advance (standard published-style values, not tuned on this data; stops and time limits
are our own additions so every trade has a defined risk). Results in R (1R = loss when the stop
is hit), costs counted, gapped stops filled at the open, swap NOT counted. Because 6 strategies are tested at once,
one could pass by luck, so the pass rule is strict. Paper research only - no real money."""
import json, os, sys
import numpy as np, pandas as pd
import research2 as r2

SPLIT = r2.SPLIT


def _ema(x, n):
    return x.ewm(span=n, adjust=False).mean()


def _rsi(c, n=14):
    d = c.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def _zeros(df):
    return np.zeros(len(df), dtype=int), np.zeros(len(df), dtype=bool), np.zeros(len(df), dtype=bool)


def s_mean_reversion(df):
    """price stretched 2 standard deviations from its 20-day average -> bet it comes back; exit at the average
    (plus our 2.5 ATR stop and 10-day limit)"""
    c = df["Close"]
    m, sd = c.rolling(20).mean(), c.rolling(20).std()
    z = ((c - m) / sd).values
    enter, xl, xs = _zeros(df)
    enter[z < -2] = 1
    enter[z > 2] = -1
    xl[z >= 0] = True
    xs[z <= 0] = True
    return enter, xl, xs


def s_momentum_12m(df):
    """12-month time-series momentum on spot, checked once a month (managed-futures style). Differences from the
    academic version: no carry/swap, a 6 ATR disaster stop, and flat after a stop until the next month"""
    c = df["Close"]
    ret = (c / c.shift(252) - 1).values
    # decide on the close of the first trading day of each month (no peeking at future dates)
    months = np.array([x.year * 12 + x.month for x in df.index])
    first_day = np.zeros(len(df), dtype=bool)
    if len(df) > 1:
        first_day[1:] = months[1:] != months[:-1]
    enter, xl, xs = _zeros(df)
    ok = first_day & ~np.isnan(ret)
    enter[ok & (ret > 0)] = 1
    enter[ok & (ret < 0)] = -1
    xl[ok & (ret < 0)] = True
    xs[ok & (ret > 0)] = True
    return enter, xl, xs


def s_turtle(df):
    """Turtle system 2: enter on a 55-day high/low, exit on a 20-day low/high"""
    C = df["Close"].values
    h55, l55 = df["High"].rolling(55).max().shift(1).values, df["Low"].rolling(55).min().shift(1).values
    h20, l20 = df["High"].rolling(20).max().shift(1).values, df["Low"].rolling(20).min().shift(1).values
    enter, xl, xs = _zeros(df)
    with np.errstate(invalid="ignore"):
        enter[C > h55] = 1
        enter[C < l55] = -1
        xl[C < l20] = True
        xs[C > h20] = True
    return enter, xl, xs


def s_trend_pullback(df):
    """Connors-style: above the 200-day average buy when RSI(2) < 10, below it sell when RSI(2) > 90; exit when the
    close crosses the 5-day average (plus our 2 ATR stop and 10-day limit)"""
    c = df["Close"]
    sma = c.rolling(200).mean().values
    s5 = c.rolling(5).mean().values
    r = _rsi(c, 2).values
    C = c.values
    enter, xl, xs = _zeros(df)
    with np.errstate(invalid="ignore"):
        enter[(C > sma) & (r < 10)] = 1
        enter[(C < sma) & (r > 90)] = -1
        xl[C > s5] = True
        xs[C < s5] = True
    return enter, xl, xs


def _from_r2(cfg):
    def f(df):
        sig = r2.signals(df, cfg)
        enter, xl, xs = _zeros(df)
        enter[:] = sig
        xl[sig == -1] = True
        xs[sig == 1] = True
        return enter, xl, xs
    return f


# cooldown: after any exit, wait one bar before a new entry (no instant doubling-down after a stop)
STRATS = {
    "mean_reversion_20d_2sd": {"make": s_mean_reversion, "stop_atr": 2.5, "max_hold": 10, "cooldown": True},
    "momentum_12m_monthly": {"make": s_momentum_12m, "stop_atr": 6.0, "max_hold": None},
    "turtle_55_20": {"make": s_turtle, "stop_atr": 2.0, "max_hold": None},
    "pullback_200_rsi2": {"make": s_trend_pullback, "stop_atr": 2.0, "max_hold": 10, "cooldown": True},
    "botB_breakout20 (baseline)": {"make": _from_r2(r2.RULES["B_breakout20"]), "stop_atr": 3.0, "max_hold": None},
    "botC_ema20_100 (baseline)": {"make": _from_r2(r2.RULES["C_ema20_100"]), "stop_atr": 3.0, "max_hold": None},
}


def backtest(df, spec, cost, next_open=False):
    """decide on the close; exit on stop (gap -> open), exit signal, opposite entry or time limit; returns [(date, R)].
    next_open=True: robustness variant, entries are filled at the NEXT bar's open instead of the signal close."""
    O, H, L, C, A = (df[k].values for k in ("Open", "High", "Low", "Close", "atr"))
    enter, xl, xs = spec["make"](df)
    mh = spec["max_hold"]
    cool = spec.get("cooldown", False)
    pos, out, pending, last_exit = None, [], None, -10
    for i in range(len(df)):
        if pending is not None and pos is None:
            sg, dist = pending
            pos = {"s": sg, "e": O[i], "dist": dist, "stop": O[i] - sg * dist, "i": i}
        pending = None
        if pos:
            s = pos["s"]
            ex = None
            if s == 1 and L[i] <= pos["stop"]:
                ex = min(O[i], pos["stop"])
            elif s == -1 and H[i] >= pos["stop"]:
                ex = max(O[i], pos["stop"])
            elif (s == 1 and (xl[i] or enter[i] == -1)) or (s == -1 and (xs[i] or enter[i] == 1)) or \
                    (mh is not None and i - pos["i"] >= mh):
                ex = C[i]
            if ex is not None:
                out.append((df.index[i], float(((ex - pos["e"]) * s - cost) / pos["dist"])))
                pos = None
                last_exit = i
        if pos is None and enter[i] and not np.isnan(A[i]) and A[i] > 0 and not (cool and last_exit == i):
            dist = spec["stop_atr"] * A[i]
            if next_open:
                pending = (int(enter[i]), dist)
            else:
                pos = {"s": int(enter[i]), "e": C[i], "dist": dist, "stop": C[i] - enter[i] * dist, "i": i}
    return out


def bootstrap_p(all_tr, lo, hi, n_boot=2000, block=20, seed=0):
    """block bootstrap over DATES of the portfolio's daily P&L (keeps the correlation between pairs).
    Returns the share of resamples whose average daily P&L is <= 0 (small = unlikely to be luck)."""
    if not all_tr:
        return 1.0
    s = pd.Series([r for _, r in all_tr], index=pd.DatetimeIndex([d for d, _ in all_tr])).groupby(lambda x: x.normalize()).sum()
    days = pd.bdate_range(lo.normalize(), hi.normalize()).union(s.index)  # keep any weekend-dated trade too
    x = s.reindex(days, fill_value=0.0).values
    n = len(x)
    if n < block * 2:
        return 1.0
    rng = np.random.default_rng(seed)
    k = int(np.ceil(n / block))
    starts = rng.integers(0, n - block + 1, size=(n_boot, k))
    idx = (starts[:, :, None] + np.arange(block)[None, None, :]).reshape(n_boot, -1)[:, :n]
    means = x[idx].mean(axis=1)
    return round(float((means <= 0).mean()), 4)


def evaluate(data, spec):
    per_pair, all_tr, firsts, lasts, no_tr = {}, [], [], [], []
    for t, df in data.items():
        no = r3_next_open(df, spec, t)
        no_tr += no
        tr = backtest(df, spec, r2.COST_PIPS.get(t, 2.0) * r2.pip(t))
        first, last = df.index[0], df.index[-1]
        firsts.append(first.tz_localize(None) if first.tzinfo else first)
        lasts.append(last.tz_localize(None) if last.tzinfo else last)
        tr = [(d.tz_localize(None) if d.tzinfo else d, r) for d, r in tr]
        sp = pd.Timestamp(SPLIT)
        yrs = (lasts[-1] - firsts[-1]).days / 365.25
        syrs = max((sp - firsts[-1]).days / 365.25, 0.1)
        per_pair[t.replace("=X", "")] = {"all": r2.stats(tr, yrs), "before_2018": r2.stats([x for x in tr if x[0] < sp], syrs),
                                         "from_2018": r2.stats([x for x in tr if x[0] >= sp], max(yrs - syrs, 0.1))}
        all_tr += [(d, r, t) for d, r in tr]
    if not firsts:
        return {"per_pair": {}, "portfolio": {"trades": 0}, "pass": False}
    lo, hi, sp = min(firsts), max(lasts), pd.Timestamp(SPLIT)
    two = lambda xs: [(d, r) for d, r, _ in xs]
    port = r2.portfolio(two(all_tr), lo, hi)
    pa = r2.portfolio(two([x for x in all_tr if x[0] < sp]), lo, sp)
    pb = r2.portfolio(two([x for x in all_tr if x[0] >= sp]), sp, hi)
    nj = r2.portfolio(two([x for x in all_tr if "JPY" not in x[2]]), lo, hi)
    pno = r2.portfolio(no_tr, lo, hi) if no_tr else {"trades": 0}
    pval = bootstrap_p(two(all_tr), lo, hi)
    good = sum(1 for p in per_pair.values() if p["all"]["trades"] and p["all"]["R"] > 0)
    n = len(per_pair)
    checks = {"profitable_on_60pct_of_pairs": n > 0 and good >= 0.6 * n,
              "portfolio_pf_over_1.2": (port.get("pf") or 0) > 1.2,
              "pf_over_1_before_2018": (pa.get("pf") or 0) > 1.0,
              "pf_over_1_from_2018": (pb.get("pf") or 0) > 1.0,
              "pf_over_1_without_jpy_pairs": (nj.get("pf") or 0) > 1.0,
              "pf_over_1_entering_next_open": (pno.get("pf") or 0) > 1.0,
              "bootstrap_luck_chance_under_1pct": pval < 0.01}
    return {"pairs_profitable": f"{good}/{n}", "checks": checks, "pass": all(checks.values()),
            "bootstrap_luck_chance": pval, "portfolio_next_open_entry": pno,
            "portfolio": port, "portfolio_before_2018": pa, "portfolio_from_2018": pb, "portfolio_non_jpy": nj,
            "per_pair": per_pair}


def r3_next_open(df, spec, t):
    tr = backtest(df, spec, r2.COST_PIPS.get(t, 2.0) * r2.pip(t), next_open=True)
    return [(d.tz_localize(None) if d.tzinfo else d, r) for d, r in tr]


def main(data=None, out_path="fx/research3.json", min_pairs=0):
    data = r2.load_all() if data is None else data
    if len(data) < min_pairs:
        print("only", len(data), "pairs downloaded - Yahoo problem? not writing a result")
        sys.exit(1)
    res = {name: {"stop_atr": sp["stop_atr"], "max_hold": sp["max_hold"], "doc": (sp["make"].__doc__ or "").strip(),
                  **evaluate(data, sp)} for name, sp in STRATS.items()}
    table = sorted(({"strategy": k, "pass": v["pass"], "pairs_profitable": v.get("pairs_profitable"),
                     "pf": v["portfolio"].get("pf"), "pnl_usd": v["portfolio"].get("pnl_usd"),
                     "luck_chance": v.get("bootstrap_luck_chance"),
                     "trades_per_year": v["portfolio"].get("trades_per_year"), "max_dd_usd": v["portfolio"].get("max_dd_usd"),
                     "losing_years": f"{v['portfolio'].get('losing_years')}/{v['portfolio'].get('years')}"}
                    for k, v in res.items()), key=lambda x: (not x["pass"], -(x["pf"] or 0)))
    out = {"note": "Fixed textbook parameters, 11 pairs, $5 risk per trade per pair, costs counted, gapped stops at the open, "
                   "swap NOT counted (matters most for the long-holding momentum rule), drawdown on closed trades only. "
                   "6 strategies tested at once, so a pass needs ALL checks, incl. a block-bootstrap luck test (<1%) and "
                   "entering at the next open. Dollar figures are not equal-risk across strategies (stop widths differ); "
                   "compare with pf and pass. A momentum pass would still need a carry/swap check. Paper research only.",
           "pairs": [t.replace("=X", "") for t in data], "pairs_dropped": dict(r2.DROPPED), "summary": table, "strategies": res}
    d = os.path.dirname(out_path)
    if d:
        os.makedirs(d, exist_ok=True)
    json.dump(out, open(out_path, "w"), indent=1)
    for row in table:
        print(row)
    return out


if __name__ == "__main__":
    main(min_pairs=6)
